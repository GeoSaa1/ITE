
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant/view/Tables/BossTablesScreen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;



class WaiterOrderController extends GetxController {



  var Done=false.obs;
  var firstOrder=[].obs;
  Future<void> viewFirstOrder() async{

    var uri= Uri.parse('http://10.0.2.2:8000/api/ViewFirstOrder');
    SharedPreferences prefs = await SharedPreferences.getInstance();



    http.Response response =
    await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},);

    print(response.statusCode);
    if(response.statusCode == 200){


      final Map json = jsonDecode(response.body);
      firstOrder.value=json['Order'];
      Done.value=true;







    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }




  var orderCount=''.obs;

  Future<void> viewWaitingListCount() async{

    var uri= Uri.parse('http://10.0.2.2:8000/api/ViewWaitingListCount');
    SharedPreferences prefs = await SharedPreferences.getInstance();



    http.Response response =
    await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},);

    print(response.statusCode);
    if(response.statusCode == 200){


      final Map json = jsonDecode(response.body);
      orderCount.value=json['Waiting orders'].toString();








    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }



  var statistics=[].obs;
  var monthlyIncome=''.obs;
  var Done2=false.obs;
  TextEditingController cookIdController=TextEditingController();
  Future<void>getFirstOrder() async{

    var uri= Uri.parse('http://10.0.2.2:8000/api/GetFirstOrder');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    Map body={
      'CookId': '${cookIdController.text}'

    };



    http.Response response =
    await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);

    print(response.statusCode);
    if(response.statusCode == 200){


      final Map json = jsonDecode(response.body);
      Get.snackbar( 'Confirmed','The order is served',
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );







    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }



}
