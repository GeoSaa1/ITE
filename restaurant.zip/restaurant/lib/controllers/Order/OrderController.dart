
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant/view/Tables/BossTablesScreen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;



class OrderController extends GetxController {

  TextEditingController editingController =TextEditingController();
  var startOrder=true.obs;
  var OrderId=''.obs;
  Future<void> customerOrder() async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/CustomerOrder');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    Map body={
      'Description': 'hurry up!'

    };
    http.Response response =
    await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);

    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      startOrder.value=false;
      OrderId.value=json['OrderId'].toString();

      prefs.setString('OrderId', OrderId.value);


    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }


  var meals=[].obs;
  var Done=false.obs;
  var catChosen='Meals'.obs;


  Future<void> viewMenu() async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/ViewMenu');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    http.Response response =
    await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'});

    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      meals.value=json['meals'];
      Done.value=true;



    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }


  var meal={}.obs;
  Future<void> getMeal(var id) async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/GetMeal');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    Map body={
      'MealId': '${id}'

    };
    http.Response response =
    await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);

    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      meal.value=json['Meal'];





    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }

TextEditingController amountController=TextEditingController();
  var mealId='';
  var condition='Real Money'.obs;
  var OrderIdDetails='';
  TextEditingController od_Description=TextEditingController();
  Future<void> customerOrderDetails() async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/CustomerOrderDetails');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    OrderIdDetails = await prefs.getString('OrderId').toString();
    mealId= await prefs.getString('MealOrderId').toString();


    Map body={
      'OrderId': '${OrderIdDetails}',
    'MealId': '${mealId}',
    'Amount': '${amountController.text}',
    'Condition': '${condition.value}',
    'Od_Description': '${od_Description.text}',

    };
    http.Response response =
    await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);

    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      if(jsonDecode(response.body)['message']!=null)
      Get.snackbar( 'Sent','${jsonDecode(response.body)['message']}',
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );
      else
        Get.snackbar( 'Sent','order sent',
          snackPosition: SnackPosition.BOTTOM,
          margin: EdgeInsets.only(bottom: 10),
          barBlur: 10000,
          backgroundColor: Colors.green,
        );
    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }


var receiptFull={};

  Future<void> receipt() async{

    var uri= Uri.parse('http://10.0.2.2:8000/api/Receipt');
    SharedPreferences prefs = await SharedPreferences.getInstance();



    http.Response response =
    await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},);

    print(response.statusCode);
    if(response.statusCode == 200){
      var receiptList=[];
      var receiptListList=[];
      var listofmaps=[];
      var namesofmeals=[];

      final Map json = jsonDecode(response.body);
      receiptFull=json['Receipt'];
      receiptList=receiptFull.values.toList();



      receiptList.forEach((element) {
        receiptListList=element;
        receiptListList.forEach((element) {
          listofmaps.add(element);


        });
      });


      Get.dialog(AlertDialog(
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
                Radius.circular(30))),
        content: Container(
          width: 300,
          height: 300,
          child: (receiptList.isNotEmpty)?Column(


            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text('Meal',
                      style: TextStyle(color: Colors.green.shade400,
                          fontWeight: FontWeight.w700,
                          fontSize: 15)),
                  Text('Amount',
                      style: TextStyle(color: Colors.green.shade400,
                          fontWeight: FontWeight.w700,
                          fontSize: 15)),

                  Text('Price',
                      style: TextStyle(color: Colors.green.shade400,
                          fontWeight: FontWeight.w700,
                          fontSize: 15)),


                ],
              ),
              Expanded(
                child: ListView.builder(
                    scrollDirection: Axis.vertical,
                    itemCount: listofmaps.length,
                    itemBuilder: (BuildContext context,int i) {



                      return Column(
                        children: [

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Text('${listofmaps[i]['Name']}',
                                  style: TextStyle(color: Colors.green.shade400,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 20)),
                              Text(' ${listofmaps[i]['Amount']}  ',
                                  style: TextStyle(color: Colors.green.shade400,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 20)),


                              Text('       ${listofmaps[i]['Price']}',
                                  style: TextStyle(color: Colors.green.shade400,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 20)),
                            ],
                          ),
                        ],
                      );
                    }
                ),
                
              ),
              Text('Total cost: ${json['Total cost']}',style: TextStyle(
                fontSize: 16,
                color: Colors.green.shade400
              ),)
            ],
          ):Center(
            child: Text('There is no orders',
                style: TextStyle(fontSize: 20,
                    fontWeight: FontWeight.w900,


                    color: Colors.yellow.shade700)),
          ),
        ),

      ),);

    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }



}
