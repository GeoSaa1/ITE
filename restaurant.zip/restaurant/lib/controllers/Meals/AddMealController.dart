import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AddMealController extends GetxController{
  TextEditingController NameController = TextEditingController();
  TextEditingController PriceController = TextEditingController();
  TextEditingController LPPriceController = TextEditingController();
  TextEditingController LoyaltyPointsController = TextEditingController();
  TextEditingController DescriptionController = TextEditingController();
  var cat='Meals'.obs;

  Future<void> addMeal() async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var uri= Uri.parse('http://10.0.2.2:8000/api/AddMeal');
    Map body = {
      'Name': NameController.text,
      'Price': PriceController.text,
      'LPPrice':LPPriceController.text,
      'LoyaltyPoints': LoyaltyPointsController.text,
      'Category': '${cat.value}',
      'Description': DescriptionController.text,
    };

    http.Response response =
    await http.post(uri,body: body,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'});
    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      Get.back();



    }

    else{
      return jsonDecode(response.body)['message'];
    }


  }


}