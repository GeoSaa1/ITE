
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
// import 'package:restaurant/view/Tables/BossTablesScreen.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:http/http.dart' as http;



class MealController extends GetxController {




  var meals=[].obs;
  var Done=false.obs;
  var catChosen='Meals'.obs;


  Future<void> viewMenu() async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/ViewMenu');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    http.Response response =
    await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'});

    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      meals.value=json['meals'];
      Done.value=true;



    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }

var meal={}.obs;
  Future<void> getMeal(var id) async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/GetMeal');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    Map body={
      'MealId': '${id}'

    };
    http.Response response =
    await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);

    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      meal.value=json['Meal'];





    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }


}
