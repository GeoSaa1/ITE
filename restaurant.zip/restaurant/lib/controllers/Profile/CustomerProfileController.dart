
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;



class CustomerProfileController extends GetxController {
  var FirstName=''.obs;
  var LastName=''.obs;
  var Birthday=''.obs;
  var Number=''.obs;
  var LoyaltyPoints=0.obs;
  var id=0.obs;
  var Visited=0.obs;
  var Canceled=0.obs;
  var DidntCome=0.obs;

  var Done=false.obs;


  Future<void> ShowProfile() async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/Profile');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    http.Response response =
    await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.get('token')}'});
    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      FirstName.value=json['FirstName'];
      LastName.value=json['LastName'];
      Number.value=json['Number'];
      Birthday.value=json['Birthday'];
      LoyaltyPoints.value=json['LoyaltyPoints'];
      Visited.value=json['Visited'];
      Canceled.value=json['Canceled'];
      DidntCome.value=json['DidntCome'];
      id.value=json['id'];
      Done.value=true;

    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }

}
