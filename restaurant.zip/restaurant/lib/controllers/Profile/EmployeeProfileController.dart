
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;



class EmployeeProfileController extends GetxController {
var FirstName=''.obs;
var LastName=''.obs;
var Role=0.obs;
var id=0.obs;
var Salary=0.obs;
var Served=0.obs;
var WorkTime=0.obs;
var Rate=0.obs;
var Done=false;


  Future<void> ShowProfile() async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/Profile');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    http.Response response =
    await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.get('token')}'});
    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      FirstName.value=json['FirstName'];
      LastName.value=json['LastName'];
      Role.value=json['Role'];
      Served.value=json['Served'];
      Salary.value=json['Salary'];
      WorkTime.value=json['WorkTime'];
      id.value=json['id'];
      Done=true;

    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }
  TextEditingController salary= TextEditingController();
Future<void> EditSalary(int id,TextEditingController salary) async{
  var uri= Uri.parse('http://10.0.2.2:8000/api/SetSalary');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  http.Response response =
  await http.post(uri,
      headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},
  body:{
    'EmployeeId': '$id',
    'Salary':'${salary.text}',
  });
  print(response.statusCode);
  if(response.statusCode == 200){}
  else {
    Get.snackbar( 'Error',jsonDecode(response.body)['message'],
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );


  }

}
}
