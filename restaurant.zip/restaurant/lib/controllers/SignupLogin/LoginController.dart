

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;



class LoginController extends GetxController {
  TextEditingController EmailController = TextEditingController();
  TextEditingController PasswordController = TextEditingController();



  Future<void> Login() async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var uri= Uri.parse('http://10.0.2.2:8000/api/Login');
    Map body = {
      'Email': EmailController.text,
      'Password': PasswordController.text,
    };
    http.Response response =
    await http.post(uri,body: body);
    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);


      if(json.values.first=='Welcome back!')
      {
        var token=json['token'];
        var user=json['user'];

        await prefs.setString('token', token);
        if(user=='customer')
        {

        Map cusInfo={};
        cusInfo=json['customer'];



        await prefs.setString('token', token);
        await prefs.setString('firstname', cusInfo['FirstName']);
        await prefs.setString('lastname', cusInfo['LastName']);
        await prefs.setString('email', cusInfo['Email']);
        Get.toNamed('/CustomerHomeScreen');

        }

        else
         {

         Map cusInfo={};
         cusInfo=json['customer'];



         await prefs.setString('token', token);
         await prefs.setString('firstname', cusInfo['FirstName']);
         await prefs.setString('lastname', cusInfo['LastName']);
         await prefs.setString('email', cusInfo['Email']);
         await prefs.setString('role', cusInfo['Role'].toString());
         if(cusInfo['Role']==1)
           Get.offNamed('/BossHomeScreen');
         if(cusInfo['Role']==2)
           Get.offNamed('/WaiterHomeScreen');

         if(cusInfo['Role']==5)
           Get.offNamed('/ParkingHomeScreen');


         }
        EmailController.text='';
        PasswordController.text='';





      }
      else{
        return jsonDecode(response.body)['message'];
      }

    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }
}
