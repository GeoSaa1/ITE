

import 'dart:convert';



import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;


class CustomerSignupController extends GetxController {
  TextEditingController FirstNameController = TextEditingController();
  TextEditingController LastNameController = TextEditingController();
  TextEditingController EmailController = TextEditingController();
  TextEditingController PasswordController = TextEditingController();
  TextEditingController NumberController = TextEditingController();
  TextEditingController BirthdayController = TextEditingController();



  Future<void> Cus_Signup() async{
    SharedPreferences prefs = await SharedPreferences.getInstance();

    print(BirthdayController.text);

  var uri= Uri.parse('http://10.0.2.2:8000/api/CustomerSignup');
  Map body = {
    'FirstName': FirstNameController.text,
    'LastName': LastNameController.text,
    'Email':EmailController.text,
    'Password': PasswordController.text,
    'Number': NumberController.text,
    'Birthday': BirthdayController.text
  };

  http.Response response =
      await http.post(uri,body: body);
  print(response.statusCode);
  if(response.statusCode == 200){
    final Map json = jsonDecode(response.body);

    if(json.values.first=='Customer registered seccessfully')
    {
      var token=json['token'];
      Map cusInfo={};
      cusInfo=json['customer'];



      await prefs.setString('token', token);
      await prefs.setString('firstname', cusInfo['FirstName']);
      await prefs.setString('lastname', cusInfo['LastName']);
      await prefs.setString('email', cusInfo['Email']);

      Get.toNamed('/CustomerHomeScreen');
    }
    else{
      return jsonDecode(response.body)['message'];
    }

  }
  else {
    Get.snackbar( 'Error',jsonDecode(response.body)['message'],
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );


  }


  }
}
