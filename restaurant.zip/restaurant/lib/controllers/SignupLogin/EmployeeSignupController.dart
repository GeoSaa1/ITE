
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';


class EmployeeSignupController extends GetxController {
  TextEditingController FirstNameController = TextEditingController();
  TextEditingController LastNameController = TextEditingController();
  TextEditingController EmailController = TextEditingController();
  TextEditingController PasswordController = TextEditingController();
  TextEditingController SalaryController = TextEditingController();
  TextEditingController RoleController = TextEditingController();



  Future<void> Emp_Signup() async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if(RoleController.text!=null&&RoleController.text!='2'
        &&RoleController.text!='3'&&RoleController.text!='4'
        &&RoleController.text!='5')
      RoleController.text='2';



    var uri= Uri.parse('http://10.0.2.2:8000/api/EmployeeSignup');
    Map body = {
      'FirstName': FirstNameController.text,
      'LastName': LastNameController.text,
      'Role': RoleController.text,
      'Email':EmailController.text,
      'Password': PasswordController.text,
      'Salary': SalaryController.text,

    };

    http.Response response =
    await http.post(uri,body: body);
    print(RoleController.text);
    print(jsonDecode(response.body));
    print(response.statusCode);

    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      if(json.values.first=='Employee registered successfully')
      {




        Get.back();
      }
      else{
        return jsonDecode(response.body)['message'];
      }

    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
     snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
      );


    }


  }
}