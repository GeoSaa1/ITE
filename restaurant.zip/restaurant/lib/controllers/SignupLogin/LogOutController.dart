

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;



class LogOutController extends GetxController {
  TextEditingController EmailController = TextEditingController();
  TextEditingController PasswordController = TextEditingController();



  Future<void> logOut() async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var uri= Uri.parse('http://10.0.2.2:8000/api/Logout');
    http.Response response =
    await http.post(uri,headers: {'Authorization': 'Bearer 30|L4Gxmtd01CiD7c5N1zIedFf8MphWDAkUck0r4Z5Z'});
    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      print('logedout');





    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }
}
