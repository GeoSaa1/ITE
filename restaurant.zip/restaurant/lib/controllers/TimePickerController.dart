import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:restaurant/controllers/Reservation/ReservationController.dart';

import 'package:get/get.dart';
class TimePickerController extends GetxController {
  ReservationController reservationController=Get.put(ReservationController());
  var selectedTime = TimeOfDay.now().obs;

  void pickTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: selectedTime.value,
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: Colors.green,
            ),
          ),
          child: child!,
        );
      },


    );
    if (picked != null) {
      selectedTime.value = picked;

    }

  }
  void pickTimeStart(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: 12, minute: 00),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: Colors.green,
            ),
          ),
          child: child!,
        );
      },


    );
    if (picked != null) {
      selectedTime.value = picked;
      var df = DateFormat("h:mm a");
      var dt = df.parse(picked!.format(context));
      reservationController.RevStart.value=  DateFormat('HH:mm').format(dt);



    }

  }
  void pickTimeEnd(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: 12, minute: 00),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: Colors.green,
            ),
          ),
          child: child!,
        );
      },


    );
    if (picked != null) {

      selectedTime.value = picked;
      var df = DateFormat("h:mm a");
      var dt = df.parse(picked!.format(context));
      reservationController.RevEnd.value=  DateFormat('HH:mm').format(dt);
      print(reservationController.RevEnd.value);





    }

  }

}