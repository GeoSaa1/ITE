
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant/view/Tables/BossTablesScreen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;



class ParkingController extends GetxController {

TextEditingController editingController =TextEditingController();
  Future<void> editParkingLots() async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/EditParkingLots');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    Map body={
      'ParkingLots': editingController.text

    };
    http.Response response =
    await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);

    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      Get.snackbar( 'Confirmed','The parking lots number is ${json['Parking lots']}',
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );

    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }
Future<void> isAvailable(int id) async{
  var uri= Uri.parse('http://10.0.2.2:8000/api/IsAvailable');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  Map body={
    'ParkingLot': '${id}'

  };
  http.Response response =
  await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);

  print(response.statusCode);
  if(response.statusCode == 200){


  }
  else {
    Get.snackbar( 'Error',jsonDecode(response.body)['message'],
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );


  }

}

var parkingLots=[].obs;
  var Done1=false.obs;
  Future<void> parkingStatus() async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/ParkingStatus');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    http.Response response =
    await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'});

    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      parkingLots.value=json['Parking Lots'];
      Done1.value=true;


    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }

  var availableLots=''.obs;
Future<void> availableParkingLots() async{
  var uri= Uri.parse('http://10.0.2.2:8000/api/AvailableParkingLots');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  http.Response response =
  await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'});

  print(response.statusCode);
  if(response.statusCode == 200){
    final Map json = jsonDecode(response.body);
    availableLots.value=json['Available Lots'].toString();


  }
  else {
    Get.snackbar( 'Error',jsonDecode(response.body)['message'],
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );


  }

}

}
