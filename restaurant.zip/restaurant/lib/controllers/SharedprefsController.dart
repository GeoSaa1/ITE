
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';



class SharedprefsController extends GetxController {
  SharedPreferences ?prefs;
  var Done=false.obs;

  Future<void> Sharedprefs() async{
    SharedPreferences prefss = await SharedPreferences.getInstance();
    prefs=prefss;
    Done.value=true;

  }


}
