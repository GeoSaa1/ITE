
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant/view/Tables/BossTablesScreen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;



class StatisticsController extends GetxController {

  // TextEditingController editingController =TextEditingController();
  // var startOrder=true.obs;
  // var OrderId=''.obs;
  // Future<void> customerOrder() async{
  //   var uri= Uri.parse('http://10.0.2.2:8000/api/CustomerOrder');
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   Map body={
  //     'Description': 'hurry up!'
  //
  //   };
  //   http.Response response =
  //   await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);
  //
  //   print(response.statusCode);
  //   if(response.statusCode == 200){
  //     final Map json = jsonDecode(response.body);
  //     startOrder.value=false;
  //     OrderId.value=json['OrderId'].toString();
  //
  //     prefs.setString('OrderId', OrderId.value);
  //
  //
  //   }
  //   else {
  //     Get.snackbar( 'Error',jsonDecode(response.body)['message'],
  //       snackPosition: SnackPosition.BOTTOM,
  //       margin: EdgeInsets.only(bottom: 10),
  //       barBlur: 10000,
  //       backgroundColor: Colors.green,
  //     );
  //
  //
  //   }
  //
  // }
  //
  //
  // var meals=[].obs;
  // var Done=false.obs;
  // var catChosen='Meals'.obs;
  //
  //
  // Future<void> viewMenu() async{
  //   var uri= Uri.parse('http://10.0.2.2:8000/api/ViewMenu');
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   http.Response response =
  //   await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'});
  //
  //   print(response.statusCode);
  //   if(response.statusCode == 200){
  //     final Map json = jsonDecode(response.body);
  //     meals.value=json['meals'];
  //     Done.value=true;
  //
  //
  //
  //   }
  //   else {
  //     Get.snackbar( 'Error',jsonDecode(response.body)['message'],
  //       snackPosition: SnackPosition.BOTTOM,
  //       margin: EdgeInsets.only(bottom: 10),
  //       barBlur: 10000,
  //       backgroundColor: Colors.green,
  //     );
  //
  //
  //   }
  //
  // }
  //
  //
  // var meal={}.obs;
  // Future<void> getMeal(var id) async{
  //   var uri= Uri.parse('http://10.0.2.2:8000/api/GetMeal');
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   Map body={
  //     'MealId': '${id}'
  //
  //   };
  //   http.Response response =
  //   await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);
  //
  //   print(response.statusCode);
  //   if(response.statusCode == 200){
  //     final Map json = jsonDecode(response.body);
  //     meal.value=json['Meal'];
  //
  //
  //
  //
  //
  //   }
  //   else {
  //     Get.snackbar( 'Error',jsonDecode(response.body)['message'],
  //       snackPosition: SnackPosition.BOTTOM,
  //       margin: EdgeInsets.only(bottom: 10),
  //       barBlur: 10000,
  //       backgroundColor: Colors.green,
  //     );
  //
  //
  //   }
  //
  // }
  //
  // TextEditingController amountController=TextEditingController();
  // var mealId='';
  // var condition='Real Money'.obs;
  // var OrderIdDetails='';
  // TextEditingController od_Description=TextEditingController();
  // Future<void> customerOrderDetails() async{
  //   var uri= Uri.parse('http://10.0.2.2:8000/api/CustomerOrderDetails');
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   OrderIdDetails = await prefs.getString('OrderId').toString();
  //   mealId= await prefs.getString('MealOrderId').toString();
  //
  //
  //   Map body={
  //     'OrderId': '${OrderIdDetails}',
  //     'MealId': '${mealId}',
  //     'Amount': '${amountController.text}',
  //     'Condition': '${condition.value}',
  //     'Od_Description': '${od_Description.text}',
  //
  //   };
  //   http.Response response =
  //   await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);
  //
  //   print(response.statusCode);
  //   if(response.statusCode == 200){
  //     final Map json = jsonDecode(response.body);
  //     Get.snackbar( 'Sent','Your Order Has Been Sent',
  //       snackPosition: SnackPosition.BOTTOM,
  //       margin: EdgeInsets.only(bottom: 10),
  //       barBlur: 10000,
  //       backgroundColor: Colors.green,
  //     );
  //   }
  //   else {
  //     Get.snackbar( 'Error',jsonDecode(response.body)['message'],
  //       snackPosition: SnackPosition.BOTTOM,
  //       margin: EdgeInsets.only(bottom: 10),
  //       barBlur: 10000,
  //       backgroundColor: Colors.green,
  //     );
  //
  //
  //   }
  //
  // }


var Done=false.obs;
var waitingList=[].obs;
  Future<void> viewWaitingList() async{

    var uri= Uri.parse('http://10.0.2.2:8000/api/ViewWaitingList');
    SharedPreferences prefs = await SharedPreferences.getInstance();



    http.Response response =
    await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},);

    print(response.statusCode);
    if(response.statusCode == 200){


      final Map json = jsonDecode(response.body);
      waitingList.value=json['waiting list'];
      Done.value=true;







    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }



var statistics=[].obs;
  var monthlyIncome=''.obs;
var Done2=false.obs;
Future<void>viewStatistics() async{

  var uri= Uri.parse('http://10.0.2.2:8000/api/ViewStatistics');
  SharedPreferences prefs = await SharedPreferences.getInstance();



  http.Response response =
  await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},);

  print(response.statusCode);
  if(response.statusCode == 200){


    final Map json = jsonDecode(response.body);
    statistics.value=json['orders'];
    monthlyIncome.value=json['monthly income'].toString();
    Done2.value=true;







  }
  else {
    Get.snackbar( 'Error',jsonDecode(response.body)['message'],
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );


  }

}



}
