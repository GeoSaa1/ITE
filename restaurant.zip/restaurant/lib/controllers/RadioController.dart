

import 'package:get/get.dart';
import 'package:restaurant/controllers/SignupLogin/EmployeeSignupController.dart';
class RadioPickerController extends GetxController {
  EmployeeSignupController employeeSignupController =
  Get.put(EmployeeSignupController());
  var selectedRole = 'Waiter'.obs;
  void pickRadio (var role) async{


    if(role=='Waiter')
      employeeSignupController.RoleController.text='2';
    if(role=='Cook')
      employeeSignupController.RoleController.text='3';
    if(role=='Delivery')
      employeeSignupController.RoleController.text='4';
    if(role=='Parking')
      employeeSignupController.RoleController.text='5';
  }

}