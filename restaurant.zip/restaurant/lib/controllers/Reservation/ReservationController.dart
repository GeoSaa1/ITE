import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ReservationController extends GetxController {






  var availableTables = {}.obs;
  var AvlTables=[].obs;
  var checkReservationMessage = ''.obs;
  var nearbyreservationAfter = {}.obs;
  var nearbyreservationBefore = {}.obs;
  var Done1 = false.obs;
  var RevDate = ''.obs;
  var RevStart = ''.obs;
  var RevEnd = ''.obs;
  var RevTables = ''.obs;
  var TablesBefore= [].obs;
  var TablesAfter= [].obs;
  TextEditingController RevTablesController = TextEditingController();
  Future<void> checkReservation() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    checkReservationMessage.value='';

    var uri = Uri.parse('http://10.0.2.2:8000/api/CheckReservation');
    Map body = {
      'RevDate': RevDate.value,
      'RevStart': RevStart.value,
      'RevEnd': RevEnd.value,
      'RevTables': RevTables.value,
    };

    http.Response response = await http.post(uri,
        headers: {
          'Authorization': 'Bearer ${prefs.getString('token')}'
        },
        body: body);

    print(jsonDecode(response.body));
    print(response.statusCode);

    if (response.statusCode == 200) {
      final Map json = jsonDecode(response.body);
      if(json['message']!=null)
      {
        checkReservationMessage.value=json['message'];
        print(checkReservationMessage.value);
        if(checkReservationMessage.value=='reservation not available')
          {
            Map m={};
            Map t={};
            Map ta= {};

            m=json['nearby reservation after'];
            t=m['original'];
            ta=t['Tables'];
            TablesAfter.value=ta.keys.toList();
            nearbyreservationAfter.value=m['original'];

            m=json['nearby reservation before'];
            t=m['original'];
            ta=t['Tables'];
            TablesBefore.value=ta.keys.toList();

            nearbyreservationBefore.value=m['original'];
          }
      }else {

        prefs.setString('RevDate', RevDate.value);
        prefs.setString('RevStart', RevStart.value);
        prefs.setString('RevEnd', RevEnd.value);
        prefs.setString('RevTables', RevTables.value.toString());
        prefs.setString('AvlTables', AvlTables.value.toString());
        availableTables.value = json['Tables'];
        AvlTables.value = availableTables.keys.toList();
      }





      Done1.value = true;
    } else {
      Get.snackbar(
        'Error',
        jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );
    }
  }





  Future<void> deleteReservation(int id) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var uri = Uri.parse('http://10.0.2.2:8000/api/DeleteReservations');
    Map body = {
      'ReservationId': '$id',
    };

    http.Response response = await http.post(uri,
        headers: {
          'Authorization': 'Bearer ${prefs.getString('token')}'
        },
        body: body);

    print(jsonDecode(response.body));
    print(response.statusCode);

    if (response.statusCode == 200) {
      final Map json = jsonDecode(response.body);
      Done4.value = false;
    } else {
      Get.snackbar(
        'Error',
        jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );
    }
  }







  int customerId = 0;
  String date = '';
  String start = '';
  String end = '';
  String customers = '';
  String reservationNamend = '';
  String possibleBirthday = '';
  var ResTables=[].obs;
  var ResDate=''.obs;
  var ResStart=''.obs;
  var ResEnd =''.obs;
  var Done3 = false.obs;
  TextEditingController customerPhoneNumberController =TextEditingController();
  TextEditingController customersNumberController =TextEditingController();
  TextEditingController reservationNameController =TextEditingController();
  Future<void> reserve() async {
    int i=0;
    for(i;i<ResTables.value.length;i++)
      {
        ResTables.value[i]=ResTables.value[i].replaceAll(RegExp('[^0-9]'), '');
      }

    SharedPreferences prefs = await SharedPreferences.getInstance();
    var uri = Uri.parse('http://10.0.2.2:8000/api/Reserve');
    Map body = {
      'CustomerNumber': '${customerPhoneNumberController.text}',
      'Date': '${RevDate.value}',
      'Start': '${ResStart.value}',
      'End': '${ResEnd.value}',
      'Customers': '${customersNumberController.text}',
      'ReservationName': '${reservationNameController.text}',
      'Tables': '${ResTables.value.join(',')}',
    };

    http.Response response = await http.post(uri,
        headers: {'Authorization': 'Bearer ${prefs.getString('token')}'}, body: body);


    print(response.statusCode);


    if (response.statusCode == 200) {
      final Map json = jsonDecode(response.body);
      Map reservations = {};

      reservations = json['reservation'];
      print('${reservations}' +'l');

      customerId = reservations['CustomerId'];
      date = reservations['Date'];
      start = reservations['Start'];
      end = reservations['End'];
      reservationNamend = reservations['ReservationName'];
      possibleBirthday = reservations['PossibleBirthday'];

      Get.snackbar(
        'Confirmed',
        'Reservation confirmed successfully',
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );

      Done3.value = true;
    }
    else {
      Get.snackbar(
        'Error',
        jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );
    }





  }






  var InfoTables=[].obs;
  List reservations = [].obs;
  var Done4 = false.obs;
  Future<void> viewReservations(String date) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    InfoTables.value=[];
    var uri = Uri.parse('http://10.0.2.2:8000/api/ViewReservations');
    Map body = {
      'Date': '$date',
    };

    http.Response response = await http.post(uri,
        headers: {'Authorization': 'Bearer ${prefs.getString('token')}'}, body: body);


    print(response.statusCode);

    if (response.statusCode == 200) {

      final Map json = jsonDecode(response.body);

      print('reservations');
      if (json['reservations'] != null)
        {
          reservations=json['reservations'];

          var x=[];
          Map z={};
          var y=[];



          int i;
          int j;


          for(j=0;j<reservations.length;j++) {
            z=reservations[j];
            x=z['Tables'];
            for (i = 0; i <x.length; i++) {
              y.add(x[i]['TableId']);
            }
            InfoTables.add(y.join(','));
            z={};
            x=[];
            y=[];


          }







        }
      else {
        print('null');
        reservations = [];
      }
      Done4.value = true;
    } else {
      Get.snackbar(
        'Error',
        jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );
    }

  }






var firstname=''.obs;
  var lastName=''.obs;
  var birthday=''.obs;

  var visited=0;
  var canceled=0;
  var didntCome=0;

  var message=''.obs;

  Future<void> showCustomer() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    var uri = Uri.parse('http://10.0.2.2:8000/api/ShowCustomer');
    Map body = {
      'Number': customerPhoneNumberController.text,
    };

    http.Response response = await http.post(uri,
        headers: {'Authorization': 'Bearer ${prefs.getString('token')}'}, body: body);


    print(response.statusCode);

    if (response.statusCode == 200) {




    Map json={};
    json=jsonDecode(response.body);
    print(json['message']);
  if(json['message']=='Customer Not Found')
    {
      print('not');
      firstname.value = '';
      lastName.value = '';
      birthday.value = '';
      visited = 0;;
      canceled = 0;
      didntCome = 0;
      Get.snackbar(
        'Error',
        jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );
    }
  else {
        firstname.value = json['FirstName'];
        lastName.value = json['LastName'];
        birthday.value = json['Birthday'];
        visited = json['Visited'];
        canceled = json['Canceled'];
        didntCome = json['DidntCome'];
        Get.dialog(
          AlertDialog(
            shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(30))),
            content: Container(
              width: 200,
              height: 150,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text('${firstname.value}' + ' ' + '${lastName.value}',
                      style: TextStyle(
                          color: Colors.green,
                          fontWeight: FontWeight.w700,
                          fontSize: 20)),
                  Text('${birthday.value}',
                      style: TextStyle(
                          color: Colors.green,
                          fontWeight: FontWeight.w700,
                          fontSize: 20)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          Text('Visited',
                              style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 17)),
                          Text('${visited}',
                              style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15)),
                        ],
                      ),
                      Column(
                        children: [
                          Text('Canceled',
                              style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 17)),
                          Text('${canceled}',
                              style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15)),
                        ],
                      ),
                      Column(
                        children: [
                          Text('DidntCome',
                              style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 17)),
                          Text('${didntCome}',
                              style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15)),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () {
                    Get.back();
                  },
                  child: Text(
                    'Close',
                    style: TextStyle(
                        color: Colors.yellow.shade600,
                        fontSize: 18,
                        fontWeight: FontWeight.w700),
                  ))
            ],
          ),
        );
      }
    } else {
      Get.snackbar(
        'Error',
        jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );
    }

  }


}
