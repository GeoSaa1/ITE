
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant/view/Tables/BossTablesScreen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;



class BossTablesController extends GetxController {

var availableTables=[].obs;
var blockedTables=[].obs;
var Done1=false.obs;
var Done2=false.obs;
  Future<void> showAvilableTables() async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/ViewAvailableTables');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    http.Response response =
    await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.get('token')}'});

    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      if(json['Available Tables']!=null)
      availableTables.value=json['Available Tables'];

      else
        availableTables.value=[];
      Done1.value=true;

    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }
Future<void> showBlockedTables() async{

  var uri= Uri.parse('http://10.0.2.2:8000/api/ViewBlockedTables');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  http.Response response =
  await http.get(uri,
      headers: {'Authorization': 'Bearer ${prefs.get('token')}'});
  print('blocked');
  print(response.statusCode);
  if(response.statusCode == 200){
    final Map json = jsonDecode(response.body);
    if(json['Available Tables']!=null)
    blockedTables.value=json['Available Tables'];
    else
    blockedTables.value=[];

    Done2.value=true;

  }
  else {
    Get.snackbar( 'Error',jsonDecode(response.body)['message'],
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );


  }

}
Future<void> blockUnblockTables(int id) async{
  SharedPreferences prefs = await SharedPreferences.getInstance();
  var uri= Uri.parse('http://10.0.2.2:8000/api/BlockUnblockTable');
  Map body = {
    'TableId': '$id'
  };

  http.Response response =
  await http.post(uri,
      headers: {'Authorization': 'Bearer ${prefs.get('token')}'},
      body: body);
  print('edit');
  print(response.statusCode);
  if(response.statusCode == 200){
    final Map json = jsonDecode(response.body);
    this.showAvilableTables();
    this.showBlockedTables();



  }
  else {
    Get.snackbar( 'Error',jsonDecode(response.body)['message'],
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );


  }


}

TextEditingController editTablesController=TextEditingController();
Future<void> editTablesNumber() async{
  SharedPreferences prefs = await SharedPreferences.getInstance();
  var uri= Uri.parse('http://10.0.2.2:8000/api/EditTables');
  Map body = {
    'Tables': '${editTablesController.text}'
  };
  http.Response response =
  await http.post(uri,
      headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},
      body: body);
  print('editnumbers');
  print(response.statusCode);
  if(response.statusCode == 200){
    final Map json = jsonDecode(response.body);
    this.showAvilableTables();
    this.showBlockedTables();



  }
  else {
    Get.snackbar( 'Error',"${response.statusCode}",
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );


  }


}




var infoList=[].obs;
Future<void> infoTable(int id) async{
  SharedPreferences prefs = await SharedPreferences.getInstance();
  var uri= Uri.parse('http://10.0.2.2:8000/api/TableInfo');
  Map body = {
    'TableId': '$id'
  };
  http.Response response =
  await http.post(uri,
      headers: {'Authorization': 'Bearer ${prefs.get('token')}'},
      body: body);

  print(response.statusCode);
  if(response.statusCode == 200){
    final List json = jsonDecode(response.body);
   infoList.value=json;
    Get.dialog(AlertDialog(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
              Radius.circular(30))),
      content: Container(
          width: 250,
          height: 140,
          child: (infoList.isNotEmpty)?ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: infoList.length,
              itemBuilder: (BuildContext context,int i) {
                print(infoList[i]['Day']);
                return Container(
                  margin:EdgeInsets.all(5),
                  decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(width: 3,color: Colors.green.shade400),

                  ),
                  padding: EdgeInsets.all(10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                  Text('${infoList[i]['Day']}',
                      style: TextStyle(color: Colors.green.shade400,
                          fontWeight: FontWeight.w700,
                          fontSize: 20)),
                      Text('${infoList[i]['from']}',
                          style: TextStyle(color: Colors.green.shade400,
                              fontWeight: FontWeight.w700,
                              fontSize: 20)),
                      Icon(Icons.arrow_downward),
                      Text('${infoList[i]['to']}',
                          style: TextStyle(color: Colors.green.shade400,
                              fontWeight: FontWeight.w700,
                              fontSize: 20)),
                    ],
                  ),
                );
              }
          ):Center(
            child: Text('There is no reservations',
                style: TextStyle(fontSize: 20,
                    fontWeight: FontWeight.w900,


                    color: Colors.yellow.shade700)),
          ),
      ),
      actions: [
        TextButton(
            onPressed: () {


              Get.back();


            },
            child: Text(
              'Close',
              style: TextStyle(
                  color: Colors.yellow.shade600,
                  fontSize: 18,
                  fontWeight: FontWeight.w600),
            ))
      ],
    ),);




  }
  else {
    Get.snackbar( 'Error',"${response.statusCode}",
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );


  }


}


}
