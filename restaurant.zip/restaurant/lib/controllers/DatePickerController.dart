import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:restaurant/controllers/Reservation/ReservationController.dart';

import 'package:get/get.dart';
class DatePickerController extends GetxController {
  ReservationController reservationController=Get.put(ReservationController());
  var selectedDate = DateTime.now().obs;

  void pickDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate.value,
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: Colors.green,
            ),
          ),
          child: child!,
        );
      },

    );
    if (picked != null) {
      selectedDate.value = picked;
    }

  }
  void pickDateReserve(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate.value,
      firstDate:DateTime(1900) ,
      lastDate: DateTime(2100),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: Colors.green,
            ),
          ),
          child: child!,
        );
      },

    );
    if (picked != null) {
      reservationController.Done4.value=false;
      selectedDate.value = picked;
    }

  }
  void pickDateCheckReserve(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate.value,
      firstDate:DateTime(1900) ,
      lastDate: DateTime(2100),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: Colors.green,
            ),
          ),
          child: child!,
        );
      },

    );
    if (picked != null) {

      selectedDate.value = picked;
      reservationController.RevDate.value=DateFormat('yyyy-MM-dd').format(selectedDate.value);
    }

  }
}