
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant/view/Tables/BossTablesScreen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;



class DeliveryControllor extends GetxController {

TextEditingController phoneNumberController=TextEditingController();
var startDone=true.obs;
  Future<void> startDelivery() async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/StartDelivery');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    Map body={
      'Number': '${phoneNumberController.text}'

    };
    http.Response response =
    await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);

    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      startDone.value=false;
      Get.snackbar( 'Confirmed','Delivery created',
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }


  var addressed=[].obs;
Future<void> viewAddresses() async{
  var uri= Uri.parse('http://10.0.2.2:8000/api/ViewAddresses');
  SharedPreferences prefs = await SharedPreferences.getInstance();

  http.Response response =
  await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'});

  print(response.statusCode);
  print('response.statusCode');
  if(response.statusCode == 200){
    final List json = jsonDecode(response.body);
    addressed.value=json;


  }
  else {
    Get.snackbar( 'Error',jsonDecode(response.body)['message'],
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );


  }

}

TextEditingController description=TextEditingController();
Future<void> deliveryOrder(var id) async{
  var uri= Uri.parse('http://10.0.2.2:8000/api/DeliveryOrder');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  Map body={
  'Description': '${description.text}',
    'AddressId': '${id}'

  };
  http.Response response =
  await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);

  print(response.statusCode);
  if(response.statusCode == 200){
    final Map json = jsonDecode(response.body);

    Get.snackbar( 'Confirmed','Delivery orderd',
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );


  }
  else {
    Get.snackbar( 'Error',jsonDecode(response.body)['message'],
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );


  }

}












  var meals=[].obs;
  var Done=false.obs;
  var catChosen='Meals'.obs;
  Future<void> viewMenu() async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/ViewMenu');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    http.Response response =
    await http.get(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'});

    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      meals.value=json['meals'];
      Done.value=true;



    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }


  var meal={}.obs;
  Future<void> getMeal(var id) async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/GetMeal');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    Map body={
      'MealId': '${id}'

    };
    http.Response response =
    await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);

    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      meal.value=json['Meal'];





    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }

  TextEditingController amountController=TextEditingController();
  var mealId='';
  var condition='Real Money'.obs;
  var OrderIdDetails='';
  TextEditingController od_Description=TextEditingController();
  Future<void> customerOrderDetails() async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/DeliveryDetails');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    OrderIdDetails = await prefs.getString('OrderId').toString();
    mealId= await prefs.getString('MealOrderId').toString();


    Map body={
      'MealId': '${mealId}',
      'Amount': '${amountController.text}',
      'Condition': '${condition.value}',
      'Od_Description': '${od_Description.text}',

    };
    http.Response response =
    await http.post(uri,headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},body: body);

    print(response.statusCode);
    if(response.statusCode == 200){
      final Map json = jsonDecode(response.body);
      Get.snackbar( 'Sent','Your Order Has Been Sent',
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );
    }
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }





}
