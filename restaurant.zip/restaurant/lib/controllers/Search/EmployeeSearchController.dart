import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class EmployeeSearchController extends GetxController {


  var Role=''.obs;
  var employees=[].obs;
  var Done1=false.obs;
  Future<void> SearchRole() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();


    var uri = Uri.parse('http://10.0.2.2:8000/api/SearchRole');
    Map body = {
      'Role': '${Role.value}',

    };

    http.Response response = await http.post(uri,
        headers: {
          'Authorization': 'Bearer ${prefs.getString('token')}'
        },
        body: body);

    print(jsonDecode(response.body));
    print(response.statusCode);

    if (response.statusCode == 200) {

      Done1.value = true;
          var json = jsonDecode(response.body);

            employees.value = json;


            Done1.value = true;

    }
    else {
      Get.snackbar(
        'Error',
        jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );
    }
  }

  TextEditingController salary=TextEditingController();
  Future<void> EditSalary(int id,TextEditingController salary) async{
    var uri= Uri.parse('http://10.0.2.2:8000/api/SetSalary');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    http.Response response =
    await http.post(uri,
        headers: {'Authorization': 'Bearer ${prefs.getString('token')}'},
        body:{
          'EmployeeId': '$id',
          'Salary':'${salary.text}',
        });
    print(response.statusCode);
    if(response.statusCode == 200){}
    else {
      Get.snackbar( 'Error',jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }

  }



}
