import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ServeController extends GetxController {


  Future<void> toServe(int id) async {
    SharedPreferences prefs=await SharedPreferences.getInstance();



    var uri = Uri.parse('http://10.0.2.2:8000/api/ToServe');
    Map body = {
      'ReservationId': '$id',

    };

    http.Response response = await http.post(uri,
        headers: {'Authorization': 'Bearer ${prefs.getString('token')}'}, body: body);


    if (response.statusCode == 200) {
      final Map json = jsonDecode(response.body);

      Get.snackbar(
        'Confirmed',
        'Serve confirmed successfully',
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }
    else {
      Get.snackbar(
        'Error',
        jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );
    }





  }


  TextEditingController phoneNumberController=TextEditingController();
  TextEditingController customersController=TextEditingController();
var Tables=[].obs;
var addPhoneNumber=false.obs;
  var l=[].obs;

Future<void> startServe() async {
  SharedPreferences prefs=await SharedPreferences.getInstance();
  print(ResTables.value);
String x=phoneNumberController.text;
int i;

for(i=0;i<ResTables.value.length;i++)
{
  l.value.add(ResTables.value[i].replaceAll(RegExp('[^0-9]'), ''));
}

if(addPhoneNumber==false)
  x='0900000000';


  var uri = Uri.parse('http://10.0.2.2:8000/api/StartServe');
  Map body = {
    'Number': '${x}',
    'Type': 'Dine in',
    'Customers': '${customersController.text}',
    'Tables': l.value.join(','),

  };

  http.Response response = await http.post(uri,
      headers: {'Authorization': 'Bearer ${prefs.getString('token')}'}, body: body);


  if (response.statusCode == 200) {
    final Map json = jsonDecode(response.body);
    print(x);
    print(response.statusCode);
    Get.snackbar(
      'Confirmed',
      'Serve confirmed successfully',
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );


  }
  else {
    Get.snackbar(
      'Error',
      jsonDecode(response.body)['message'],
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.only(bottom: 10),
      barBlur: 10000,
      backgroundColor: Colors.green,
    );
  }





}





var  AvlTables=[].obs;
var ResTables=[].obs;
  var Done1=false.obs;
  Future<void> serveAvailableTables() async {
    SharedPreferences prefs=await SharedPreferences.getInstance();

    var uri = Uri.parse('http://10.0.2.2:8000/api/ServeAvailableTables');


    http.Response response = await http.get(uri,
        headers: {'Authorization': 'Bearer ${prefs.getString('token')}'});


    if (response.statusCode == 200) {
      final Map json = jsonDecode(response.body);

      print(response.statusCode);
      AvlTables.value=json.keys.toList();

Done1.value=true;

    }
    else {
      Get.snackbar(
        'Error',
        jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );
    }





  }

TextEditingController endController=TextEditingController();
  Future<void> endServe() async {
    SharedPreferences prefs=await SharedPreferences.getInstance();



    var uri = Uri.parse('http://10.0.2.2:8000/api/EndServe');
    Map body = {
      'TableId': '${endController.text}',
    };

    http.Response response = await http.post(uri,
        headers: {'Authorization': 'Bearer ${prefs.getString('token')}'}, body: body);


    if (response.statusCode == 200) {
      final Map json = jsonDecode(response.body);
      serveAvailableTables();
      ResTables.value=[];

      Get.snackbar(
        'Confirmed',
        'Serve ended successfully',
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );


    }
    else {
      Get.snackbar(
        'Error',
        'no serve at this table',
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );
    }





  }



















  var firstname=''.obs;
  var lastName=''.obs;
  var birthday=''.obs;
  var visited=0;
  var canceled=0;
  var didntCome=0;
  Future<void> showCustomer() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    var uri = Uri.parse('http://10.0.2.2:8000/api/ShowCustomer');
    Map body = {
      'Number': phoneNumberController.text,
    };

    http.Response response = await http.post(uri,
        headers: {'Authorization': 'Bearer ${prefs.getString('token')}'}, body: body);


    print(response.statusCode);

    if (response.statusCode == 200) {




      Map json=jsonDecode(response.body);

      if(json['message']=='Customer Not Found')
      {
        print('not');
        firstname.value = '';
        lastName.value = '';
        birthday.value = '';
        visited = 0;;
        canceled = 0;
        didntCome = 0;
        Get.snackbar(
          'Error',
          jsonDecode(response.body)['message'],
          snackPosition: SnackPosition.BOTTOM,
          margin: EdgeInsets.only(bottom: 10),
          barBlur: 10000,
          backgroundColor: Colors.green,
        );
      }
      else {
        firstname.value = json['FirstName'];
        lastName.value = json['LastName'];
        birthday.value = json['Birthday'];
        visited = json['Visited'];
        canceled = json['Canceled'];
        didntCome = json['DidntCome'];
        Get.dialog(
          AlertDialog(
            shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(30))),
            content: Container(
              width: 200,
              height: 150,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text('${firstname.value}' + ' ' + '${lastName.value}',
                      style: TextStyle(
                          color: Colors.green,
                          fontWeight: FontWeight.w700,
                          fontSize: 20)),
                  Text('${birthday.value}',
                      style: TextStyle(
                          color: Colors.green,
                          fontWeight: FontWeight.w700,
                          fontSize: 20)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          Text('Visited',
                              style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 17)),
                          Text('${visited}',
                              style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15)),
                        ],
                      ),
                      Column(
                        children: [
                          Text('Canceled',
                              style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 17)),
                          Text('${canceled}',
                              style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15)),
                        ],
                      ),
                      Column(
                        children: [
                          Text('DidntCome',
                              style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 17)),
                          Text('${didntCome}',
                              style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15)),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () {
                    Get.back();
                  },
                  child: Text(
                    'Close',
                    style: TextStyle(
                        color: Colors.yellow.shade600,
                        fontSize: 18,
                        fontWeight: FontWeight.w700),
                  ))
            ],
          ),
        );
      }
    } else {
      Get.snackbar(
        'Error',
        jsonDecode(response.body)['message'],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.only(bottom: 10),
        barBlur: 10000,
        backgroundColor: Colors.green,
      );
    }

  }




}
