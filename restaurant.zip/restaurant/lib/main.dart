import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant/view/Screens/BossHomeScreen.dart';
import 'package:restaurant/view/Screens/CustomerHomeScreen.dart';
import 'package:restaurant/view/Screens/Delivery/DeliveryProfileOrderScreen.dart';
import 'package:restaurant/view/Screens/Delivery/DeliveryScreen.dart';
import 'package:restaurant/view/Screens/Delivery/DeliveryScreenMeal.dart';
import 'package:restaurant/view/Screens/Meels/AddMeal.dart';
import 'package:restaurant/view/Screens/Meels/MealsProfile.dart';
import 'package:restaurant/view/Screens/Meels/MealsScreen.dart';
import 'package:restaurant/view/Screens/Order/MealProfileOrder.dart';
import 'package:restaurant/view/Screens/Order/OrderScreen.dart';
import 'package:restaurant/view/Screens/Order/WaiterOrdersScreen.dart';
import 'package:restaurant/view/Screens/Parking/CustomerParkingScreen.dart';
import 'package:restaurant/view/Screens/Parking/ParkingScreen.dart';
import 'package:restaurant/view/Screens/ParkingHomeScreen.dart';
import 'package:restaurant/view/Screens/Profile/CustomerProfileScreen.dart';
import 'package:restaurant/view/Screens/Reservation/CheckReservationsScreen.dart';
import 'package:restaurant/view/Screens/Reservation/ReserveScreen.dart';
import 'package:restaurant/view/Screens/Reservation/ViewReservationScreen.dart';
import 'package:restaurant/view/Screens/SearchEmployee/SearchEmployeeScreen.dart';
import 'package:restaurant/view/Screens/SearchEmployee/SearchRole.dart';
import 'package:restaurant/view/Screens/Serve/ServeScreen.dart';
import 'package:restaurant/view/Screens/SignupAndLogin/CustomerSignupScreen.dart';
import 'package:restaurant/view/Screens/SignupAndLogin/LoginScreen.dart';
import 'package:restaurant/view/Screens/Profile/EmployeeProfileScreen.dart';
import 'package:restaurant/view/Screens/StatisticsScreen.dart';
import 'package:restaurant/view/Screens/WaiterHomeScreen.dart';
import 'package:restaurant/view/Screens/WaitingListScreen.dart';
import 'package:restaurant/view/Tables/BossTablesScreen.dart';
import 'package:restaurant/view/Screens/CustomerHomeScreen2.dart';


import 'view/Screens/SignupAndLogin/EmployeeSignupScreen.dart';
import 'view/Screens/Home.dart';




void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});


  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
        theme: ThemeData(
          unselectedWidgetColor: Colors.greenAccent,
          textTheme: const TextTheme(
            titleMedium:
            TextStyle(
              color: Colors.grey,
              fontWeight: FontWeight.w700,
            ),),
          textSelectionTheme: const TextSelectionThemeData(
              cursorColor: Colors.green
          ),
          primaryColor: Colors.greenAccent,
          inputDecorationTheme:(
              InputDecorationTheme(



                floatingLabelStyle:const TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.w700
                ),
                labelStyle: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: Colors.grey

                ),
                enabledBorder: OutlineInputBorder(


                  borderRadius: BorderRadius.circular(Checkbox.width),
                  borderSide: const BorderSide(width: 3,color:Colors.green  ),
                ),
                focusedBorder: OutlineInputBorder(



                  borderRadius: BorderRadius.circular(Checkbox.width),
                  borderSide: const BorderSide(
                    width: 3,
                    color: Colors.green,
                  ),
                ),
                errorBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                      color: Colors.red,
                    ),
                    borderRadius: BorderRadius.circular(18)),
                focusedErrorBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                      color: Colors.red,
                    ),
                    borderRadius: BorderRadius.circular(18)),
                errorStyle: const TextStyle(fontSize: 13,
                fontWeight: FontWeight.w600),
                floatingLabelBehavior: FloatingLabelBehavior.never,
                filled: true,
                fillColor: Colors.white,


              )
          ),
        ),
        debugShowCheckedModeBanner:false ,
        home: Home(),
        getPages: [
          GetPage(name: '/', page: () => Home()),
          GetPage(name: '/LoginScreen', page: () => LoginScreen()),
          GetPage(name: '/CustomerSignupScreen', page:()=> CustomerSignupScreen() ),
          GetPage(name: '/CustomerHome2', page: () => CustomerHomeScreen2()),
          GetPage(name: '/CustomerHomeScreen', page: () => CustomerHomeScreen()),
          GetPage(name: '/EmployeeSignupScreen', page: () => EmployeeSignupScreen()),
          GetPage(name: '/BossHomeScreen', page: () => BossHomeScreen()),
          GetPage(name: '/ParkingHomeScreen', page: () => ParkingHomeScreen()),
          GetPage(name: '/WaiterHomeScreen', page: () => WaiterHomeScreen()),
          GetPage(name: '/SearchEmployeeScreen', page: () => SearchEmployeeScreen()),
          GetPage(name: '/SearchRole', page: () => SearchRole()),
          GetPage(name: '/EmployeeProfileScreen', page: () => EmployeeProfileScreen()),
          GetPage(name: '/CustomerProfileScreen', page: () => CustomerProfileScreen()),
          GetPage(name: '/BossTablesScreen', page: () => BossTablesScreen()),
          GetPage(name: '/ViewReservationScreen', page: () => ViewReservationScreen()),
          GetPage(name: '/CheckReservationsScreen', page: () => CheckReservationsScreen()),
          GetPage(name: '/ParkingScreen', page: () => ParkingScreen()),
          GetPage(name: '/ServeScreen', page: () => ServeScreen()),
          GetPage(name: '/ReserveScreen', page: () => ReserveScreen()),
          GetPage(name: '/OrderScreen', page: () => OrderScreen()),
          GetPage(name: '/MealsScreen', page: () => MealsScreen()),
          GetPage(name: '/MealProfile', page: () => MealProfile()),
          GetPage(name: '/WaiterOrderScreen', page: () => WaiterOrderScreen()),
          GetPage(name: '/DeliveryScreen', page: () => DeliveryScreen()),
          GetPage(name: '/CustomerParkingScreen', page: () => CustomerParkingScreen()),
          GetPage(name: '/StatisticsScreen', page: () => StatisticsScreen()),
          GetPage(name: '/WaitingListScreen', page: () => WaitingListScreen()),
          GetPage(name: '/MealProfileOrder', page: () => MealProfileOrder()),
          GetPage(name: '/DeliveryProfileOrderScreen', page: () => DeliveryProfileOrderScreen()),
          GetPage(name: '/DeliveryScreenMeal', page: () => DeliveryScreenMeal()),

          GetPage(name: '/AddMeal', page: () => AddMeal()),
          GetPage(name: '/Home', page: () => Home()),


        ],
    );


  }


}
