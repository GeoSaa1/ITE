import 'package:flutter/foundation.dart';

class Meal{
  final String id;
  final String name; //1
  final double price; //2
  final double LPprice;
  final double LoyaltyPoints;  //3
  final String category;
  final String description;
  final String imageURL;  //4


  Meal({
    required this.id,
    required this.name,
    required this.price,
    required this.LPprice,
    required this.LoyaltyPoints,
    required this.category,
    required this.description,
    required this.imageURL,

});
}