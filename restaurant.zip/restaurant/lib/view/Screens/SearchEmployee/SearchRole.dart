import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:restaurant/controllers/Reservation/ReservationController.dart';
import 'package:restaurant/controllers/Serve/ServeController.dart';

import 'package:restaurant/view/Widgets/InputTextFormField.dart';
import 'package:restaurant/controllers/Search/EmployeeSearchController.dart';


class SearchRole extends StatelessWidget {
  final formKey = GlobalKey<FormState>();
  SearchRole({super.key});
  EmployeeSearchController employeeSearchController = Get.put(EmployeeSearchController());

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          backgroundColor: Colors.green.shade400,


        ),

        body: Obx(() {
          if(employeeSearchController.Done1.value==false) {
            employeeSearchController.SearchRole();
            return Container(
                height: 190,
                child: Center(
                  child: CircularProgressIndicator(
                      color: Colors.green, backgroundColor: Colors.yellow),
                ));
          } else {
            if(employeeSearchController.employees.isNotEmpty)
              return RefreshIndicator(
                color: Colors.green.shade400,
                backgroundColor: Colors.yellow.shade600,
                onRefresh:() =>  employeeSearchController.SearchRole(),
                child: ListView.builder(

                    itemCount: employeeSearchController.employees.length,
                    itemBuilder: (context, i) {
                      return Container(
                        margin: EdgeInsets.all(15),
                        decoration: BoxDecoration(
                            color: Colors.green.shade400,
                            shape: BoxShape.rectangle,
                            borderRadius: BorderRadius.circular(20)
                        ),

                        height: 170,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Text(
                              '${employeeSearchController.employees[i]['FirstName']} ${employeeSearchController.employees[i]['LastName']}',
                              style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white),
                            ),
                            Text(
                              '${employeeSearchController.employees[i]['Email']}',
                              style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Text(
                                  'Served: ',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white),
                                ),
                                Text(
                                  '${employeeSearchController.employees[i]['Served']}',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.yellow.shade600),
                                ),
                                Text(
                                  'WorkTime: ',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white),
                                ),
                                Text(
                                  '${employeeSearchController.employees[i]['WorkTime']}',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.yellow.shade600),
                                ),

                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'Salary:',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white),
                                ),
                                SizedBox(width: 10,),
                                Text(
                                  '${employeeSearchController.employees[i]['Salary']}',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.yellow.shade600),
                                ),
                                SizedBox(width: 1,),
                                Container(
                                  height: 25,
                                  child: IconButton(

                                      onPressed: () {
                                        Get.dialog(AlertDialog(
                                          shape: const RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(30))),
                                          content: Container(
                                            width: 150,
                                            height: 102,
                                            child: Column(
                                              children: [
                                                Text('Salary',
                                                    style: TextStyle(
                                                        color: Colors.green,
                                                        fontWeight: FontWeight.w700,
                                                        fontSize: 20)),
                                                SizedBox(
                                                  height: 20,
                                                ),
                                                InputTextFormField(employeeSearchController.salary, 'Number', 'NumberValidator')
                                              ],
                                            ),
                                          ),
                                          actions: [
                                            TextButton(
                                                onPressed: () {

                                                  employeeSearchController.EditSalary(employeeSearchController.employees[i]['id'], employeeSearchController.salary);
                                                  employeeSearchController.SearchRole();
                                                  Get.back();


                                                },
                                                child: Text(
                                                  'Submit',
                                                  style: TextStyle(
                                                      color: Colors.yellow.shade600,
                                                      fontSize: 18,
                                                      fontWeight: FontWeight.w700),
                                                ))
                                          ],
                                        ),);
                                      },
                                      icon: Icon(
                                        Icons.edit,
                                        color: Colors.green.shade50,
                                      )),
                                ),
                              ],
                            )

                          ],
                        ),
                      );
                    }),
              );
            else
              return   RefreshIndicator(
                color: Colors.green.shade400,
                backgroundColor: Colors.yellow.shade600,
                onRefresh:() =>  employeeSearchController.SearchRole(),
                child: ListView.builder(

                    itemCount: 1,
                    itemBuilder: (context, i) {
                      return Container(
                          margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
                          height: 150,
                          padding: EdgeInsets.all(10),
                          child: Center(
                            child: Text('There is no employees',
                                style: TextStyle(fontSize: 22,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 2,

                                    color: Colors.yellow.shade700)),
                          )

                      );
                    }),
              );
          }
        })



    );
  }
}
