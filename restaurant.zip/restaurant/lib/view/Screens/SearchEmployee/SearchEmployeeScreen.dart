import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:restaurant/controllers/Search/EmployeeSearchController.dart';

import 'package:restaurant/view/Models/Card_Info.dart';
import 'package:restaurant/view/Widgets/Cards.dart';

class SearchEmployeeScreen extends StatelessWidget{
  EmployeeSearchController employeeSearchController = Get.put(EmployeeSearchController());
  final List<CardsInfo> loadedCards = [
    CardsInfo(
      id: '1',
      title: 'Waiter',
      imageURL: 'assets/Table.jpg',
      pageURL: '/BossTablesScreen'   ,
    ),
    CardsInfo(
      id: '2',
      title: 'Cook',
      imageURL: 'assets/Meals2.png',
      pageURL: '/MealsScreen',
    ),
    CardsInfo(
      id: '3',
      title: 'Delivery',
      imageURL: 'assets/Table.jpg',
      pageURL: ''  ,
    ),
    CardsInfo(
      id: '4',
      title: 'Parking',
      imageURL: 'assets/serve.jpg',
      pageURL: '/ServeScreen'  ,
    ),

  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        actions: [
          IconButton(onPressed: (){
            Get.toNamed('/EmployeeSignupScreen');

          }, icon: Icon(Icons.add))
        ],
        backgroundColor: Colors.green.shade400,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(

            )),
        centerTitle: true,
        title: Text('Employees'),
        // automaticallyImplyLeading: false,
      ),

      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton(onPressed: (){
                employeeSearchController.employees.value=[];
                employeeSearchController.Done1.value=false;

                employeeSearchController.Role.value='2';
                employeeSearchController.SearchRole();
                Get.toNamed('/SearchRole');
              },
                  style: ButtonStyle(
                      shape: MaterialStatePropertyAll(CircleBorder()),
                      padding: MaterialStatePropertyAll(EdgeInsets.all(43)),
                      elevation: MaterialStatePropertyAll(20),

                      backgroundColor: MaterialStatePropertyAll(

                          Colors.green.shade400)),
                  child: Container(
                    child: Text('Waiters',
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2,
                          fontSize: 20,
                          color: Colors.yellow.shade600
                      ),
                    ),
                  )),
              ElevatedButton(onPressed: (){
                employeeSearchController.employees.value=[];
                employeeSearchController.Done1.value=false;
                employeeSearchController.Role.value='3';
                employeeSearchController.SearchRole();
                Get.toNamed('/SearchRole');
              },
                  style: ButtonStyle(
                      shape: MaterialStatePropertyAll(CircleBorder()),
                      padding: MaterialStatePropertyAll(EdgeInsets.all(43)),
                      elevation: MaterialStatePropertyAll(20),

                      backgroundColor: MaterialStatePropertyAll(

                          Colors.green.shade400)),
                  child: Container(
                    child: Text('Cooks',
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2,
                          fontSize: 20,
                          color: Colors.yellow.shade600
                      ),
                    ),
                  )),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton(onPressed: (){
                employeeSearchController.employees.value=[];
                employeeSearchController.Done1.value=false;
                employeeSearchController.Role.value='4';
                employeeSearchController.SearchRole();
                Get.toNamed('/SearchRole');
              },
                  style: ButtonStyle(
                      shape: MaterialStatePropertyAll(CircleBorder()),
                      padding: MaterialStatePropertyAll(EdgeInsets.all(43)),
                      elevation: MaterialStatePropertyAll(20),

                      backgroundColor: MaterialStatePropertyAll(

                          Colors.green.shade400)),
                  child: Container(
                    child: Text('Delivery',
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2,
                          fontSize: 20,
                          color: Colors.yellow.shade600
                      ),
                    ),
                  )),
              ElevatedButton(onPressed: (){
                employeeSearchController.employees.value=[];
                employeeSearchController.Done1.value=false;
                employeeSearchController.Role.value='5';
                employeeSearchController.SearchRole();
                Get.toNamed('/SearchRole');
              },
                  style: ButtonStyle(
                      shape: MaterialStatePropertyAll(CircleBorder()),
                      padding: MaterialStatePropertyAll(EdgeInsets.all(43)),
                      elevation: MaterialStatePropertyAll(20),

                      backgroundColor: MaterialStatePropertyAll(

                          Colors.green.shade400)),
                  child: Container(
                    child: Text('Parkings',
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2,
                          fontSize: 20,
                          color: Colors.yellow.shade600
                      ),
                    ),
                  )),
            ],
          )
        ],
      )
    );
  }
}



