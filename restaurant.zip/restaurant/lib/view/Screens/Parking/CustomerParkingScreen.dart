import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:restaurant/controllers/Parking/ParkingController.dart';
import 'package:restaurant/controllers/SharedprefsController.dart';
import 'package:restaurant/controllers/SignupLogin/LogOutController.dart';
import 'package:restaurant/view/Models/Card_Info.dart';



class CustomerParkingScreen extends StatelessWidget{

  ParkingController parkingController=Get.put(ParkingController());
  SharedprefsController sharedprefsController=Get.put(SharedprefsController());
  LogOutController logOutController=Get.put(LogOutController());


  @override
  Widget build(BuildContext context) {
    sharedprefsController.Sharedprefs();
    parkingController.parkingStatus();
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.green.shade400,

          centerTitle: true,
          title: Text('Parking Lots'),
          actions: [

            Obx(() {
              parkingController.availableParkingLots();
              return Container(
                  margin: EdgeInsets.all(10),
                  child: Center(child: Text('${parkingController.availableLots.value}',
                    style: TextStyle(
                        fontSize: 20
                    ),)));
            }),


          ],
          // automaticallyImplyLeading: false,
        ),

        body: Obx(() {

          if(parkingController.Done1==true)
          {
            if(parkingController.parkingLots.isEmpty){
              return RefreshIndicator(
                color: Colors.yellow.shade600,
                backgroundColor: Colors.green.shade400,
                onRefresh:(){

                  parkingController.parkingStatus();

                  parkingController.Done1.value=false;
                  return parkingController.availableParkingLots();



                },
                child: ListView.builder(
                    scrollDirection: Axis.vertical,
                    itemCount: 1,
                    itemBuilder: (BuildContext context,int i) {
                      return  Center(
                        child: Container(
                          margin: EdgeInsets.only(top:  MediaQuery.of(context).size.height/3),
                          child: Text('There is no parking lots',
                              style: TextStyle(fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 2,

                                  color: Colors.yellow.shade700)),
                        ),
                      );
                    }
                ),
              );

            }
            else {
              return  RefreshIndicator(
                onRefresh:(){

                  parkingController.parkingStatus();
                  parkingController.Done1.value=false;
                  return          parkingController.availableParkingLots();

                },
                child: GridView.builder(
                    physics: BouncingScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 1.1,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                    ),
                    scrollDirection: Axis.vertical,
                    itemCount: parkingController.parkingLots.length,
                    itemBuilder: (BuildContext context,int i) {
                      return Container(
                          margin: EdgeInsets.all(10),
                          width: 130,
                          height: 130,

                          decoration: BoxDecoration(
                              color: Colors.green.shade400,
                              shape: BoxShape.rectangle,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: List.filled(1, BoxShadow(color: Colors.grey,blurRadius: 5,offset: Offset(1, 1)))),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [

                              Text('${parkingController.parkingLots[i]['id']}',
                                  style: TextStyle(color: Colors.white,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 20)),
                              (parkingController.parkingLots[i]['Condition']=='In use')
                                  ?Text('${parkingController.parkingLots[i]['Condition']}',
                                  style: TextStyle(color: Colors.white,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 20)):Text('${parkingController.parkingLots[i]['Condition']}',
                                  style: TextStyle(color: Colors.yellow.shade600,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 20)),


                            ],
                          ));
                    }
                ),
              );
            }

          }else
            return Center(
              child: CircularProgressIndicator(
                  color: Colors.green, backgroundColor: Colors.yellow),
            );



        })
    );
  }
}



