import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:restaurant/controllers/Parking/ParkingController.dart';
import 'package:restaurant/controllers/SharedprefsController.dart';
import 'package:restaurant/controllers/SignupLogin/LogOutController.dart';
import 'package:restaurant/view/Models/Card_Info.dart';



class ParkingScreen extends StatelessWidget{
  final List<CardsInfo> loadedCards = [
    CardsInfo(
      id: '1',
      title: 'Tables',
      imageURL: 'assets/Table.jpg',
      pageURL: '/BossTablesScreen'   ,
    ),
    CardsInfo(
      id: '2',
      title: 'Meals',
      imageURL: 'assets/Meals2.png',
      pageURL: '/MealsScreen',
    ),
    CardsInfo(
      id: '3',
      title: 'Waiters',
      imageURL: 'assets/Table.jpg',
      pageURL: ''  ,
    ),
    CardsInfo(
      id: '4',
      title: 'Serve',
      imageURL: 'assets/serve.jpg',
      pageURL: '/ServeScreen'  ,
    ),
    CardsInfo(
      id: '5',
      title: 'Reservations',
      imageURL: 'assets/Table.jpg',
      pageURL: '/ViewReservationScreen'  ,
    ),
    CardsInfo(
      id: '6',
      title: 'Check',
      imageURL: 'assets/Table.jpg',
      pageURL: '/CheckReservationsScreen'  ,
    ),
    CardsInfo(
      id: '7',
      title: 'Employees',
      imageURL: 'assets/Table.jpg',
      pageURL: ''  ,
    ),
    CardsInfo(
      id: '8',
      title: 'Delivery',
      imageURL: 'assets/delivery.jpg',
      pageURL: ''  ,
    ),
    CardsInfo(
      id: '9',
      title: 'Parking',
      imageURL: 'assets/parking.jpg',
      pageURL: ''  ,
    ),

  ];
  ParkingController parkingController=Get.put(ParkingController());
  SharedprefsController sharedprefsController=Get.put(SharedprefsController());
  LogOutController logOutController=Get.put(LogOutController());


  @override
  Widget build(BuildContext context) {
    sharedprefsController.Sharedprefs();
    parkingController.parkingStatus();
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.green.shade400,

          centerTitle: true,
          title: Text('Parking Lots'),
          actions: [

            Obx(() {
              parkingController.availableParkingLots();
              return Container(
                  margin: EdgeInsets.all(10),
                  child: Center(child: Text('${parkingController.availableLots.value}',
                    style: TextStyle(
                        fontSize: 20
                    ),)));
            }),


          ],
          // automaticallyImplyLeading: false,
        ),
        drawer: Drawer(
          child: Column(children: [
            Obx(() {
              if (sharedprefsController.Done.value == true) {
                return UserAccountsDrawerHeader(
                    decoration: BoxDecoration(
                        color: Colors.green.shade400,
                        borderRadius: BorderRadius.only(bottomRight: Radius.circular(20),bottomLeft: Radius.circular(20))),
                    accountName: Text(
                      "${sharedprefsController.prefs!.getString('firstname')}" +
                          ' ' +
                          '${sharedprefsController.prefs?.getString('lastname')}',
                      style: TextStyle(fontSize: 25,color: Colors.white),
                    ),
                    accountEmail: Text(
                      "${sharedprefsController.prefs!.getString('email')}",
                      style: TextStyle(fontSize: 17,color: Colors.yellow.shade600),
                    ));
              } else {
                return Container(
                    height: 190,

                    child: Center(
                      child: CircularProgressIndicator(
                          color: Colors.green, backgroundColor: Colors.yellow),
                    ));
              }
            }),
            ListTile(

              title: Text("Profile",
                style: TextStyle(fontSize: 17,color: Colors.green.shade400),
              ),
              leading: Icon(
                Icons.exit_to_app,
                color: Colors.green.shade400,
              ),
              onTap: () {

                Get.toNamed('EmployeeProfileScreen');
              },
            ),
            ListTile(

              title: Text("Logout",
                style: TextStyle(fontSize: 17,color: Colors.green.shade400),
              ),
              leading: Icon(
                Icons.exit_to_app,
                color: Colors.green.shade400,
              ),
              onTap: () {
                logOutController.logOut();
                Get.offNamed('LoginScreen');
              },
            ),

          ]),


        ),
        body: Obx(() {

          if(parkingController.Done1==true)
          {
            if(parkingController.parkingLots.isEmpty){
              return RefreshIndicator(
                color: Colors.yellow.shade600,
                backgroundColor: Colors.green.shade400,
                onRefresh:(){

                  parkingController.parkingStatus();

                  parkingController.Done1.value=false;
                  return parkingController.availableParkingLots();



                },
                child: ListView.builder(
                    scrollDirection: Axis.vertical,
                    itemCount: 1,
                    itemBuilder: (BuildContext context,int i) {
                      return  Center(
                        child: Container(
                          margin: EdgeInsets.only(top:  MediaQuery.of(context).size.height/3),
                          child: Text('There is no parking lots',
                              style: TextStyle(fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 2,

                                  color: Colors.yellow.shade700)),
                        ),
                      );
                    }
                ),
              );

            }
            else {
              return  RefreshIndicator(
                onRefresh:(){

                  parkingController.parkingStatus();
                  parkingController.Done1.value=false;
                  return          parkingController.availableParkingLots();

                },
                child: GridView.builder(
                    physics: BouncingScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 1.1,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                    ),
                    scrollDirection: Axis.vertical,
                    itemCount: parkingController.parkingLots.length,
                    itemBuilder: (BuildContext context,int i) {
                      return Container(
                          margin: EdgeInsets.all(10),
                          width: 130,
                          height: 130,

                          decoration: BoxDecoration(
                              color: Colors.green.shade400,
                              shape: BoxShape.rectangle,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: List.filled(1, BoxShadow(color: Colors.grey,blurRadius: 5,offset: Offset(1, 1)))),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [

                              Text('${parkingController.parkingLots[i]['id']}',
                                  style: TextStyle(color: Colors.white,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 20)),
                              (parkingController.parkingLots[i]['Condition']=='In use')
                                  ?Text('${parkingController.parkingLots[i]['Condition']}',
                                  style: TextStyle(color: Colors.white,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 20)):Text('${parkingController.parkingLots[i]['Condition']}',
                                  style: TextStyle(color: Colors.yellow.shade600,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 20)),
                              ElevatedButton(
                                onPressed: (){
                                  parkingController.isAvailable(parkingController.parkingLots[i]['id']);
                                  parkingController.parkingStatus();
                                  parkingController.availableParkingLots();






                                },
                                child: (parkingController.parkingLots[i]['Condition']=='In use')?Icon(Icons.minimize,color: Colors.green):Icon(Icons.add,color: Colors.green),
                                style: ButtonStyle(

                                  shape: MaterialStatePropertyAll(CircleBorder()),
                                  backgroundColor: MaterialStatePropertyAll(Colors.yellow.shade600),

                                ),
                              ),

                            ],
                          ));
                    }
                ),
              );
            }

          }else
            return Center(
              child: CircularProgressIndicator(
                  color: Colors.green, backgroundColor: Colors.yellow),
            );



        })
    );
  }
}



