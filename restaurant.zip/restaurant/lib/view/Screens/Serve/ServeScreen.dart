import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import 'package:restaurant/view/Widgets/InputTextFormField.dart';
import 'package:restaurant/controllers/Serve/ServeController.dart';
class ServeScreen extends StatelessWidget {
  final formKey = GlobalKey<FormState>();
  ServeController serveController=Get.put(ServeController());
  ServeScreen({super.key});

  @override
  Widget build(BuildContext context) {


    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          backgroundColor: Colors.green.shade400,
          actions: [
            Container(
              margin: EdgeInsets.all(7),
              child: ElevatedButton(

                style: ButtonStyle(
                  backgroundColor: MaterialStatePropertyAll(Colors.white),

                  shape: MaterialStatePropertyAll(CircleBorder(

                  ))
                ),
                  onPressed: (){
                    Get.dialog(AlertDialog(
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                              Radius.circular(30))),
                      content: Container(
                        width: 150,
                        height: 102,
                        child: Column(
                          children: [
                            Text('Choose Table Id',
                                style: TextStyle(
                                    color: Colors.green,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 20)),
                            SizedBox(
                              height: 20,
                            ),
                            InputTextFormField(serveController.endController, 'Number', 'NumberValidator')
                          ],
                        ),
                      ),
                      actions: [
                        TextButton(
                            onPressed: () {

                              serveController.endServe();
                              Get.back();


                            },
                            child: Text(
                              'End',
                              style: TextStyle(
                                  color: Colors.yellow.shade600,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700),
                            ))
                      ],
                    ),);

                  },
                  child: Text(
                    'End',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: Colors.green.shade400
                    ),
                  )
              ),
            )
          ],
        ),
        body: Form(
          key: formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [

              Obx(
                  (){
                    if(serveController.addPhoneNumber.value==false){
                      return Container(

                        decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          borderRadius: BorderRadius.circular(10),

                        ),
                        width: MediaQuery.of(context).size.width/1.5,

                        child: ElevatedButton(
                          style: ButtonStyle(
                              backgroundColor: MaterialStatePropertyAll(Colors.green.shade400),
                              shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15)))
                          ),



                          onPressed: (){
                            serveController.addPhoneNumber.value=true;
                          }
                          , child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,

                          children: [
                            Text(
                              'Add a Phone Number',
                              style: TextStyle(
                                  color: Colors.white
                              ),
                            ),
                            Icon(Icons.add)
                          ],
                        ),
                        ),
                      );
                    }
                    else {
                      return Container(
                        height:90,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            SizedBox(
                                width: MediaQuery.of(context).size.width/1.5,
                                child: Stack(
                                  children: [
                                    InputTextFormField(serveController.phoneNumberController, 'Phone Number', 'PhoneNumberValidator'),
                                    (RegExp(r'^(?:[+0]9)?[0-9]{10}$').hasMatch(serveController.phoneNumberController.text))
                                        ?Positioned(
                                        right: -20,
                                        bottom: -11,
                                        child: Obx(
                                                (){
                                              serveController.firstname.value;

                                              return  ElevatedButton(


                                                onPressed: (){
                                                  serveController.showCustomer();

                                                },
                                                child: Icon(Icons.info),
                                                style: ButtonStyle(
                                                    backgroundColor: MaterialStatePropertyAll(Colors.green.shade400),
                                                    iconColor: MaterialStatePropertyAll(Colors.white),
                                                    shape: MaterialStatePropertyAll(CircleBorder())
                                                ),
                                              );
                                            }
                                        )
                                    )
                                        :SizedBox()
                                  ],
                                )),
                            ElevatedButton(
                              style: ButtonStyle(
                                  backgroundColor: MaterialStatePropertyAll(Colors.green.shade400),
                                  shape: MaterialStatePropertyAll(CircleBorder())
                              ),



                              onPressed: (){
                                serveController.addPhoneNumber.value=false;
                              }
                              , child: Icon(Icons.remove),
                            ),
                          ],
                        ),
                      );
                    }
                  }
              ),
              SizedBox(
                height: 90,
                  width: MediaQuery.of(context).size.width/2-20,
                  child: InputTextFormField(serveController.customersController, 'Customers number', 'NumberValidator')),


             Obx(() {
               if(serveController.Done1.value==false)
                 serveController.serveAvailableTables();

               return Column(
                 children: [
                   Column(
                     children: [
                       Text(
                         'Available Tables',
                         style: TextStyle(
                             fontSize: 22,
                             fontWeight: FontWeight.w700,
                             color: Colors.green.shade400),
                       ),
                       Container(
                         margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                         color: Colors.yellow.shade600,
                         height: 4,
                         width: 150,
                       ),
                       Container(
                         height: 120,

                         child:
                         serveController.AvlTables.value.isNotEmpty
                             ?ListView.builder(
                             scrollDirection: Axis.horizontal,
                             itemCount: serveController.AvlTables.value.length,
                             itemBuilder: (BuildContext context, int i) {
                               return Container(
                                   margin: EdgeInsets.all(10),
                                   width: 70,
                                   height: 110,
                                   decoration: BoxDecoration(
                                       color: Colors.green.shade400,
                                       shape: BoxShape.rectangle,
                                       borderRadius: BorderRadius.circular(20),
                                       boxShadow: List.filled(
                                           1,
                                           BoxShadow(
                                               color: Colors.grey,
                                               blurRadius: 5,
                                               offset: Offset(1, 1)))),
                                   child: Column(
                                     mainAxisAlignment:
                                     MainAxisAlignment.spaceEvenly,
                                     children: [
                                       Text('${serveController.AvlTables.value[i]}',
                                           style: TextStyle(
                                               color: Colors.white,
                                               fontWeight: FontWeight.w700,
                                               fontSize: 16)),
                                       ElevatedButton(
                                         onPressed: () {

                                           serveController.ResTables.value.add(serveController.AvlTables.value[i]);
                                           serveController.AvlTables.value.removeAt(i);
                                           var x =serveController.AvlTables.value;
                                           serveController.AvlTables.value=[];
                                           serveController.AvlTables.value=x;

                                           print(serveController.AvlTables.value);
                                           print(serveController.ResTables.value);
                                         },
                                         child:
                                         Icon(Icons.add, color: Colors.green),
                                         style: ButtonStyle(
                                             shape: MaterialStatePropertyAll(
                                                 CircleBorder()),
                                             backgroundColor:
                                             MaterialStatePropertyAll(
                                                 Colors.yellow.shade600)),
                                       )
                                     ],
                                   ));
                             })
                             :Center(
                           child: Text('Nothing is Available',
                               style: TextStyle(fontSize: 22,
                                   fontWeight: FontWeight.w900,
                                   letterSpacing: 3,

                                   color: Colors.yellow.shade700)),
                         ),
                       ),
                     ],
                   ),
                   Column(
                     children: [
                       Text(
                         'Chosen Tables',
                         style: TextStyle(
                             fontSize: 22,
                             fontWeight: FontWeight.w700,
                             color: Colors.green.shade400),
                       ),
                       Container(
                         margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                         color: Colors.yellow.shade600,
                         height: 4,
                         width: 150,
                       ),
                       Text(
                         '${serveController.ResTables.value.length}',
                         style: TextStyle(
                             fontSize: 18,
                             fontWeight: FontWeight.w700,
                             color: Colors.yellow.shade600),
                       ),
                       Container(
                         height: 120,
                         child: serveController.ResTables.value.isNotEmpty
                             ?ListView.builder(
                             scrollDirection: Axis.horizontal,
                             itemCount: serveController.ResTables.value.length,
                             itemBuilder: (BuildContext context, int i) {
                               return Container(
                                   margin: EdgeInsets.all(10),
                                   width: 70,
                                   height: 110,
                                   decoration: BoxDecoration(
                                       color: Colors.green.shade400,
                                       shape: BoxShape.rectangle,
                                       borderRadius: BorderRadius.circular(20),
                                       boxShadow: List.filled(
                                           1,
                                           BoxShadow(
                                               color: Colors.grey,
                                               blurRadius: 5,
                                               offset: Offset(1, 1)))),
                                   child: Column(
                                     mainAxisAlignment:
                                     MainAxisAlignment.spaceEvenly,
                                     children: [
                                       Text('${serveController.ResTables.value[i]}',
                                           style: TextStyle(
                                               color: Colors.white,
                                               fontWeight: FontWeight.w700,
                                               fontSize: 16)),
                                       ElevatedButton(
                                         onPressed: () {
                                           serveController.AvlTables.value.add(serveController.ResTables.value[i]);
                                           serveController.ResTables.value.removeAt(i);
                                           serveController.ResTables.value=serveController.ResTables.value;
                                           var x =serveController.ResTables.value;
                                           serveController.ResTables.value=[];
                                           serveController.ResTables.value=x;
                                           print(serveController.AvlTables.value.toString());
                                           print(serveController.ResTables.value);
                                         },
                                         child: Icon(Icons.remove,
                                             color: Colors.green),
                                         style: ButtonStyle(
                                             shape: MaterialStatePropertyAll(
                                                 CircleBorder()),
                                             backgroundColor:
                                             MaterialStatePropertyAll(
                                                 Colors.yellow.shade600)),
                                       )
                                     ],
                                   ));
                             })
                             :Center(
                           child: Text('Nothing is chosen',
                               style: TextStyle(fontSize: 22,
                                   fontWeight: FontWeight.w900,
                                   letterSpacing: 3,

                                   color: Colors.yellow.shade700)),
                         ),
                       ),
                     ],
                   ),
                 ],
               );
             }),
              ElevatedButton(
                style: ButtonStyle(
                    backgroundColor: MaterialStatePropertyAll(
                      Colors.yellow.shade700,
                    ),
                    shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                    padding: MaterialStatePropertyAll(EdgeInsets.all(0)),
                    elevation: MaterialStatePropertyAll(10)
                ),
                child: Container(

                  width: 120,
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Start Serve',
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w700),
                      ),

                    ],
                  ),
                ),
                onPressed: () {
                  if (formKey.currentState!.validate()) {

                     serveController.startServe();
                     serveController.Done1.value=false;


                  }
                },
              )




            ],
          ),
        ));
  }
}
