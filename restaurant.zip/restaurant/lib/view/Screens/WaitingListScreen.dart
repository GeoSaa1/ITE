import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:restaurant/controllers/SharedprefsController.dart';

import 'package:restaurant/controllers/StatisticsController.dart';


class WaitingListScreen extends StatelessWidget {

  SharedprefsController sharedprefsController =
  Get.put(SharedprefsController());
  StatisticsController statisticsController =
  Get.put(StatisticsController());

  @override
  Widget build(BuildContext context) {
    sharedprefsController.Sharedprefs();

    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.green.shade400,
          centerTitle: true,
          title: Text('Waiting List'),
          // automaticallyImplyLeading: false,
        ),

        body: Obx(() {
          if(statisticsController.Done.value==true) {
            return ListView.builder(
                scrollDirection: Axis.vertical,
                itemCount: statisticsController.waitingList.value.length,
                itemBuilder: (BuildContext context,int i) {



                  return Container(
                    height: 200,
                    margin: EdgeInsets.all(10),
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(


                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: Colors.green
                        )
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Row(
                              children: [
                                Text('Id: ',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                                Text('${statisticsController.waitingList[i]['id']}',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                              ],
                            ),
                            Row(
                              children: [
                                Text('minutes waiting: ',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                                Text('${statisticsController.waitingList[i]['minutes waiting']}',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                              ],
                            ),

                            Row(
                              children: [
                                Text('Price: ',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                                Text('${statisticsController.waitingList[i]['Price']}',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                              ],
                            ),

                          ],
                        ),



                      ],
                    ),
                  );
                }
            );
          } else {
            statisticsController.viewWaitingList();
            return Center(
              child: CircularProgressIndicator(
                  color: Colors.green, backgroundColor: Colors.yellow),
            );
          }
        })
    );
  }
}
