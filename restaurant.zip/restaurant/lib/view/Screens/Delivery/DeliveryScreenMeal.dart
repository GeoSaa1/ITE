import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:restaurant/controllers/Delivery/DeliveryController.dart';

import 'package:restaurant/view/Widgets/MealInfo.dart';


class DeliveryScreenMeal extends StatelessWidget {
  DeliveryControllor deliveryControllor=Get.put(DeliveryControllor());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {},
      //   backgroundColor: Colors.green,
      //   child: Icon(Icons.shopping_cart),
      // ),
      appBar: AppBar(
        backgroundColor: Colors.green.shade400,
        title: Text('Meals'),


      ),
      body: Obx((){
        if(deliveryControllor.Done.value==true) {

          return RefreshIndicator(
            color: Colors.yellow.shade400,
            backgroundColor: Colors.green.shade400,
            onRefresh: (){
              deliveryControllor.Done.value=false;
              return deliveryControllor.viewMenu();


            },
            child: ListView.builder(


              itemCount: deliveryControllor.meals.value.length,
              itemBuilder: (context, i)
              {
                if(deliveryControllor.meals.value[i]['Category'].toString()=='Meals')
                  return MealInfo(
                    deliveryControllor.meals.value[i]['id'].toString(),
                    deliveryControllor.meals.value[i]['Name'],
                    deliveryControllor.meals.value[i]['Price'],
                    deliveryControllor.meals.value[i]['LPPrice'],
                    deliveryControllor.meals.value[i]['LoyaltyPoints'],
                    deliveryControllor.meals.value[i]['Category'].toString(),
                    deliveryControllor.meals.value[i]['Description'].toString(),
                    'assets/Pizza.jpg',

                  );
                else if(deliveryControllor.meals.value[i]['Category'].toString()=='Salads')
                  return MealInfo(
                    deliveryControllor.meals.value[i]['id'].toString(),
                    deliveryControllor.meals.value[i]['Name'],
                    deliveryControllor.meals.value[i]['Price'],
                    deliveryControllor.meals.value[i]['LPPrice'],
                    deliveryControllor.meals.value[i]['LoyaltyPoints'],
                    deliveryControllor.meals.value[i]['Category'].toString(),
                    deliveryControllor.meals.value[i]['Description'].toString(),
                    'assets/cesersalad.jpg',


                  );
                else
                  return MealInfo(
                    deliveryControllor.meals.value[i]['id'].toString(),
                    deliveryControllor.meals.value[i]['Name'],
                    deliveryControllor.meals.value[i]['Price'],
                    deliveryControllor.meals.value[i]['LPPrice'],
                    deliveryControllor.meals.value[i]['LoyaltyPoints'],
                    deliveryControllor.meals.value[i]['Category'].toString(),
                    deliveryControllor.meals.value[i]['Description'].toString(),
                    'assets/drinks.jpg',


                  );



              },

            ),
          );
        }
        else {
          deliveryControllor.viewMenu();
          return CircularProgressIndicator(
            backgroundColor: Colors.green,
            color: Colors.yellow.shade600,
          );
        }
      }),
    );
  }
}
