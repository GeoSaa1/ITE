import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant/controllers/Delivery/DeliveryController.dart';
import 'package:restaurant/view/Widgets/InputTextFormField.dart';
import 'package:restaurant/view/Widgets/MealInfo.dart';

import 'package:restaurant/view/Widgets/MealInfoOrder.dart';

class DeliveryScreen extends StatelessWidget {
  final formKey = GlobalKey<FormState>();
  DeliveryControllor deliveryControllor = Get.put(DeliveryControllor());

  DeliveryScreen({super.key});

  @override
  Widget build(BuildContext context) {


    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          backgroundColor: Colors.green.shade400,
          actions: [
            Obx(() {
              if (deliveryControllor.startDone.value == false)
                return TextButton(
                    onPressed: () {
                      deliveryControllor.startDone.value = true;
                    },
                    child: Text(
                      'End Order',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    ));
              else
                return Container();
            })
          ],
        ),
        body: Obx(() {

            if (deliveryControllor.startDone.value == false) {
              return Obx(() {
                return Column(
                  children: [
                    SizedBox(
                      height: 20,
                    ),
                    Form(
                      key: formKey,
                      child: Container(
                          width: 230,
                          child: InputTextFormField(
                              deliveryControllor.description,
                              'description',
                              '')),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Expanded(
                      child: ListView.builder(
                          itemCount: deliveryControllor.addressed.length,
                          itemBuilder: (context, i) {
                            print(deliveryControllor.addressed[i]);
                            return Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Text(
                                        '${deliveryControllor.addressed[i]['Name']}'),
                                    Icon(Icons.arrow_forward_outlined),
                                    ElevatedButton(
                                        style: ButtonStyle(
                                            backgroundColor:
                                                MaterialStatePropertyAll(
                                                    Colors.green.shade400)),
                                        onPressed: () {
                                          if (formKey.currentState!
                                              .validate()) {
                                            deliveryControllor.deliveryOrder(
                                                deliveryControllor.addressed[i]
                                                    ['id']);
                                            deliveryControllor.viewMenu();
                                            Get.toNamed('DeliveryScreenMeal');
                                          }
                                        },
                                        child: Text(
                                          'Order',
                                          style: TextStyle(color: Colors.white),
                                        ))
                                  ],
                                )
                              ],
                            );
                          }),
                    ),
                  ],
                );
              });
            } else {
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Form(
                    key: formKey,
                    child: Container(
                        width: 230,
                        child: InputTextFormField(
                            deliveryControllor.phoneNumberController,
                            'Phone Number',
                            'PhoneNumberValidator')),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Center(
                    child: ElevatedButton(
                      style: ButtonStyle(
                          foregroundColor:
                              MaterialStatePropertyAll(Colors.yellow.shade600),
                          elevation: MaterialStatePropertyAll(20),
                          padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                          backgroundColor:
                              MaterialStatePropertyAll(Colors.green.shade400),
                          shape: MaterialStatePropertyAll(
                              RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20)))),
                      onPressed: () {
                        if (formKey.currentState!.validate()) {
                          deliveryControllor.startDelivery();
                          deliveryControllor.viewAddresses();
                        }
                      },
                      child: Text('Start Delivery',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1)),
                    ),
                  ),
                ],
              );
            }


        }));
  }
}
