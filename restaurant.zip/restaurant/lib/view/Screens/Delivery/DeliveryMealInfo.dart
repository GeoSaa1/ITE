import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:restaurant/controllers/Delivery/DeliveryController.dart';

import 'package:restaurant/controllers/SharedprefsController.dart';


class DeliveryMealInfo extends StatelessWidget {
  DeliveryControllor deliveryControllor=Get.put(DeliveryControllor());
  SharedprefsController sharedprefsController=Get.put(SharedprefsController());
  final String id;
  final String name; //1
  final int price; //2
  final int LPprice;
  final int LoyaltyPoints;  //3
  final String category;
  final String description;
  final String imageURL;

  DeliveryMealInfo(
      this.id,
      this.name,
      this.price,
      this.LPprice,
      this.LoyaltyPoints,
      this.category,
      this.description,
      this.imageURL,

      );

  @override
  Widget build(BuildContext context) {
    return GridTile(
      child:GestureDetector(
        onTap: () {
          sharedprefsController.prefs!.setString('qMealId', id);
          Get.toNamed('DeliveryProfileOrderScreen');


        },
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          width: MediaQuery.of(context).size.width,
          height: 180,

          decoration: BoxDecoration(
            color: Colors.green.shade400,
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                offset: Offset(0.0, 10.0,),
                blurRadius: 10.0,
                spreadRadius: -6.0,),
            ],
            image: DecorationImage(
              colorFilter: ColorFilter.mode(
                Colors.black.withOpacity(0.1),
                BlendMode.multiply,
              ),
              image: AssetImage(imageURL,),
              fit: BoxFit.cover,
            ),
          ),
          child: Stack(
            children: [
              Align(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5.0),
                  child: Text(
                    name,
                    style: TextStyle(color: Colors.white,
                      fontSize: 30,
                    ),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 2,
                    textAlign: TextAlign.center,
                  ),
                ),
                alignment: Alignment.center,
              ),
              Align(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.4),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.price_change_rounded,
                            color: Colors.yellow,
                            size: 18,
                          ),
                          SizedBox(width: 7),
                          Text(
                              style: TextStyle(
                                  color: Colors.white),
                              price.toString()),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.4),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Row(
                        children: [
                          SizedBox(width: 7),
                          Text('LP ',style: TextStyle(
                              color: Colors.white),),
                          Text(
                              style: TextStyle(
                                  color: Colors.white)
                              ,LoyaltyPoints.toString()),

                        ],
                      ),
                    ),
                  ],
                ),
                alignment: Alignment.bottomLeft,
              ),
            ],
          ),
        ),
      ),
    );
  }
}