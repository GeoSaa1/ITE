import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:restaurant/controllers/Order/OrderController.dart';

import 'package:restaurant/view/Widgets/MealInfoOrder.dart';
class OrderScreen extends StatelessWidget {
  final formKey = GlobalKey<FormState>();
  OrderController orderController=Get.put(OrderController());
  OrderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    orderController.viewMenu();


    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          backgroundColor: Colors.green.shade400,
          actions: [
            Obx(() {
             if (orderController.startOrder.value==false)
              return TextButton(


                  onPressed: (){
                    orderController.startOrder.value=true;

                  }, child: Text('End Order',style: TextStyle(
                  fontSize: 16,
                  color: Colors.white
              ),));
             else
               return Container();
            })

          ],
        ),
        body: Form(
          key: formKey,
          child:  Obx(
                  (){
                if(orderController.startOrder.value==false){
                  return Column(


                    children: [
                      SizedBox(height: 15,),

                      Obx((){
                        if(orderController.Done.value==true) {

                          return Expanded(
                            child: RefreshIndicator(
                              color: Colors.yellow.shade400,
                              backgroundColor: Colors.green.shade400,
                              onRefresh: (){
                                orderController.Done.value=false;
                                return orderController.viewMenu();


                              },
                              child: ListView.builder(
                                physics: BouncingScrollPhysics(),

                                itemCount: orderController.meals.value.length,
                                itemBuilder: (context, i)
                                {
                                  if(orderController.meals.value[i]['Category'].toString()=='Meals')
                                    return MealInfoOrder(
                                      orderController.meals.value[i]['id'].toString(),
                                      orderController.meals.value[i]['Name'],
                                      orderController.meals.value[i]['Price'],
                                      orderController.meals.value[i]['LPPrice'],
                                      orderController.meals.value[i]['LoyaltyPoints'],
                                      orderController.meals.value[i]['Category'].toString(),
                                      orderController.meals.value[i]['Description'].toString(),
                                      'assets/Pizza.jpg',

                                    );
                                  else if(orderController.meals.value[i]['Category'].toString()=='Salads')
                                    return MealInfoOrder(
                                      orderController.meals.value[i]['id'].toString(),
                                      orderController.meals.value[i]['Name'],
                                      orderController.meals.value[i]['Price'],
                                      orderController.meals.value[i]['LPPrice'],
                                      orderController.meals.value[i]['LoyaltyPoints'],
                                      orderController.meals.value[i]['Category'].toString(),
                                      orderController.meals.value[i]['Description'].toString(),
                                      'assets/cesersalad.jpg',


                                    );
                                  else
                                    return MealInfoOrder(
                                      orderController.meals.value[i]['id'].toString(),
                                      orderController.meals.value[i]['Name'],
                                      orderController.meals.value[i]['Price'],
                                      orderController.meals.value[i]['LPPrice'],
                                      orderController.meals.value[i]['LoyaltyPoints'],
                                      orderController.meals.value[i]['Category'].toString(),
                                      orderController.meals.value[i]['Description'].toString(),
                                      'assets/drinks.jpg',


                                    );



                                },

                              ),
                            ),
                          );
                        }
                        else {

                          return Center(
                            child: CircularProgressIndicator(
                              backgroundColor: Colors.green,
                              color: Colors.yellow.shade600,
                            ),
                          );
                        }
                      })
                    ],
                  );
                }
                else {
                  return Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Center(
                        child: ElevatedButton(
                          style: ButtonStyle(

                            foregroundColor: MaterialStatePropertyAll(Colors.yellow.shade600),
                            elevation: MaterialStatePropertyAll(20),
                            padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                              backgroundColor: MaterialStatePropertyAll(Colors.green.shade400),
                              shape: MaterialStatePropertyAll(
                                  RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)
                              ))
                          ),



                          onPressed: (){
                            orderController.customerOrder();

                          }
                          , child: Text('Start Order',
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight:
                            FontWeight.w700,
                          letterSpacing: 1
                        )),
                        ),
                      ),
                      Center(
                        child: ElevatedButton(
                          style: ButtonStyle(

                              foregroundColor: MaterialStatePropertyAll(Colors.yellow.shade600),
                              elevation: MaterialStatePropertyAll(20),
                              padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                              backgroundColor: MaterialStatePropertyAll(Colors.green.shade400),
                              shape: MaterialStatePropertyAll(
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20)
                                  ))
                          ),



                          onPressed: (){



                            orderController.receipt();

                          }
                          , child: Text('Receipt',
                            style: TextStyle(
                                fontSize: 30,
                                fontWeight:
                                FontWeight.w700,
                                letterSpacing: 1
                            )),
                        ),
                      ),

                    ],
                  );
                }
              }
          ),
        ));
  }
}
