import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import 'package:restaurant/controllers/Order/OrderController.dart';
import 'package:restaurant/controllers/SharedprefsController.dart';
import 'package:restaurant/view/Widgets/InputTextFormField.dart';

class MealProfileOrder extends StatelessWidget {

  OrderController orderController=Get.put(OrderController());
  SharedprefsController sharedprefsController=Get.put(SharedprefsController());

  final formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    orderController.getMeal(sharedprefsController.prefs!.getString('MealOrderId'));
    return Scaffold(
        appBar: AppBar( backgroundColor: Colors.green.shade400,

        ),
        body: Obx((){


          return Padding(
            padding: EdgeInsets.only(top: 5),
            child:
            Column(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 25.0),
                      child: ListView(
                        children: [
                          if(orderController.meal.value['Category']=='Meals')
                            Image.asset(
                              'assets/Pizza.jpg',
                              height: 220,
                            )
                          else if(orderController.meal.value['Category']=='Salads')
                            Image.asset(

                              'assets/cesersalad.jpg'

                              ,
                              height: 220,
                            )
                          else
                            Image.asset(

                              'assets/drinks.jpg',
                              height: 220,
                            ),
                          SizedBox(height: 25,),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Icon(
                                Icons.price_change_rounded,
                                color: Colors.green,
                              ),
                              SizedBox(width: 5,),

                              Text('price:',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text('${orderController.meal.value['Price']}',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              // SizedBox(width: 7,),

                              Container(
                                padding: EdgeInsets.only(left: 10),
                                margin: EdgeInsets.all(10),
                                child: Row(
                                  children: [
                                    Text('LPprice: ',
                                      style:
                                      TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),),
                                    Text(
                                      '${orderController.meal.value['LPPrice']}',
                                      style:
                                      TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    SizedBox(width: 20,),
                                    Text(
                                      'LoyaltyPoints:',
                                      style:
                                      TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      '${orderController.meal.value['LoyaltyPoints']}',
                                      style:
                                      TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),

                                    )

                                  ],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 8,),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('${orderController.meal.value['Name']}',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 28
                                ),
                              ),
                              Text('Rate: ${orderController.meal.value['Rate']}',
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 17
                                ),
                              ),
                            ],
                          ),

                          SizedBox(height: 10,),

                          Text(
                            "description",
                            style: TextStyle(
                                color: Colors.grey[900],
                                fontWeight: FontWeight.bold,
                                fontSize: 19
                            ),
                          ),

                          Text(
                            '${orderController.meal.value['Description']}',
                            style: TextStyle(
                              color: Colors.grey[600],
                              fontSize: 17,
                              height: 2,
                            ),
                          ),
                          SizedBox(height: 10,),
                          Form(
                            key: formKey,
                              child: Column(
                                children: [
                                  InputTextFormField(orderController.amountController, 'Amount', 'NumberValidator'),
                                  SizedBox(height: 10,),
                                  InputTextFormField(orderController.od_Description, 'Description', 'AnyThing'),
                                  SizedBox(height: 10,),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      (orderController.condition.value=='Real Money')?
                                      ElevatedButton(
                                          style: ButtonStyle(
                                              backgroundColor:
                                              MaterialStatePropertyAll(Colors.green.shade400),
                                              shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(20)))),
                                          onPressed: () {
                                            orderController.condition.value='Real Money';
                                          },
                                          child: Text('Real Money'))
                                          :ElevatedButton(
                                          style: ButtonStyle(
                                              backgroundColor:
                                              MaterialStatePropertyAll(Colors.white),
                                              shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(20)))),
                                          onPressed: () {
                                            orderController.condition.value='Real Money';
                                          },
                                          child: Text('Real Money',style: TextStyle(color: Colors.green.shade400),)),
                                      (orderController.condition.value=='Loyalty Points')?
                                      ElevatedButton(
                                          style: ButtonStyle(
                                              backgroundColor:
                                              MaterialStatePropertyAll(Colors.green.shade400),
                                              shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(20)))),
                                          onPressed: () {
                                            orderController.condition.value='Loyalty Points';
                                          },
                                          child: Text('Loyalty Points')):ElevatedButton(
                                          style: ButtonStyle(
                                              backgroundColor:
                                              MaterialStatePropertyAll(Colors.white),
                                              shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(20)))),
                                          onPressed: () {
                                            orderController.condition.value='Loyalty Points';
                                          },
                                          child: Text('Loyalty Points',style: TextStyle(color: Colors.green.shade400),))

                                    ],
                                  ),
                                  SizedBox(height: 10,),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      ElevatedButton(

                                          style: ButtonStyle(
                                              padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                              backgroundColor:
                                              MaterialStatePropertyAll(Colors.yellow.shade600),
                                              shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(20)))),
                                          onPressed: () {
                                            if (formKey.currentState!.validate()) {

                                              orderController.customerOrderDetails();





                                            }

                                          },
                                          child: Text('Order',style: TextStyle(color: Colors.green.shade400),)),
                                    ],
                                  )

                                ],
                              )
                          )
                        ],
                      ),
                    ),
                  ),

                ]
            ),
          );
        })
    );
  }
}
