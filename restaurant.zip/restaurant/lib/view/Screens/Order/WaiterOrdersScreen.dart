import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:restaurant/controllers/Order/WaiterOrdersController.dart';
import 'package:restaurant/controllers/SharedprefsController.dart';
import 'package:restaurant/controllers/SignupLogin/LogOutController.dart';
import 'package:restaurant/view/Widgets/InputTextFormField.dart';


class WaiterOrderScreen extends StatelessWidget{
  final formKey = GlobalKey<FormState>();

  SharedprefsController sharedprefsController =
  Get.put(SharedprefsController());
  LogOutController logOutController = Get.put(LogOutController());
  WaiterOrderController waiterOrderController=Get.put(WaiterOrderController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.green.shade400,

        centerTitle: true,
        title: Text('Orders List'),
        actions: [
          Obx(() {
            waiterOrderController.viewWaitingListCount();


            return Center(child: Container(
                margin: EdgeInsets.fromLTRB(0, 0, 20, 0),
                child: Text(
                    '${waiterOrderController.orderCount.value}',
                style: TextStyle(fontSize: 20),
                )));
          })
        ],
        // automaticallyImplyLeading: false,
      ),

      body:Obx(() {
        if(waiterOrderController.Done.value==true) {
          if(waiterOrderController.firstOrder.isNotEmpty) {
            return Column(
              children: [

                Expanded(
                  child: ListView.builder(
                      scrollDirection: Axis.vertical,
                      itemCount: waiterOrderController.firstOrder.value.length,
                      itemBuilder: (BuildContext context,int i) {



                        return Container(
                          height: 300,
                          margin: EdgeInsets.all(10),
                          padding: EdgeInsets.all(10),
                          decoration: BoxDecoration(


                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                  color: Colors.green
                              )
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  Text('MealId: ',
                                      style: TextStyle(color: Colors.green.shade400,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 20)),
                                  Text('${waiterOrderController.firstOrder[i]['MealId']}',
                                      style: TextStyle(color: Colors.green.shade400,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 20)),
                                  Text('Amount: ',
                                      style: TextStyle(color: Colors.green.shade400,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 20)),
                                  Text('${waiterOrderController.firstOrder[i]['Amount']}',
                                      style: TextStyle(color: Colors.green.shade400,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 20)),
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  Row(
                                    children: [

                                      Text('${waiterOrderController.firstOrder[i]['Condition']}',
                                          style: TextStyle(color: Colors.green.shade400,
                                              fontWeight: FontWeight.w700,
                                              fontSize: 20)),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Text('Price: ',
                                          style: TextStyle(color: Colors.green.shade400,
                                              fontWeight: FontWeight.w700,
                                              fontSize: 20)),
                                      Text('${waiterOrderController.firstOrder[i]['Price']}',
                                          style: TextStyle(color: Colors.green.shade400,
                                              fontWeight: FontWeight.w700,
                                              fontSize: 20)),
                                    ],
                                  ),



                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('Od_Description: ',
                                      style: TextStyle(color: Colors.green.shade400,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 20)),
                                  Text('${waiterOrderController.firstOrder[i]['Od_Description']}',
                                      style: TextStyle(color: Colors.green.shade400,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 20)),
                                ],
                              ),





                            ],
                          ),
                        );
                      }
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(color: Colors.green.shade400),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Form(
                          key:formKey ,
                          child: Container(
                              width: 200,
                              child: InputTextFormField(waiterOrderController.cookIdController, 'CookId', 'NumberValidator'))),
                      ElevatedButton(
                          style: ButtonStyle(
                              shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20)
                              )),
                              backgroundColor: MaterialStatePropertyAll(Colors.white)),
                          onPressed: (){
                            if (formKey.currentState!.validate()) {
                              waiterOrderController.getFirstOrder();
                              waiterOrderController.viewFirstOrder();
                            }

                          }, child: Text('Get',style:
                      TextStyle(color: Colors.green.shade400,
                          fontSize: 17,
                          fontWeight: FontWeight.w700)
                        ,))

                    ],
                  ),
                )
              ],
            );
          } else
            return
                Center(
                  child:Text('There is no order',
                  style: TextStyle(
                    color: Colors.yellow.shade600,
                    fontSize: 30,
                    letterSpacing: 2,
                    fontWeight: FontWeight.w700
                  )),
                );
        } else {
          waiterOrderController.viewFirstOrder();
          return Center(
            child: CircularProgressIndicator(
                color: Colors.green, backgroundColor: Colors.yellow),
          );
        }
      })
    );
  }
}



