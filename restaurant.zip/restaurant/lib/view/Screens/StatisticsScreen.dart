import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:restaurant/controllers/SharedprefsController.dart';

import 'package:restaurant/controllers/StatisticsController.dart';


class StatisticsScreen extends StatelessWidget {

  SharedprefsController sharedprefsController =
  Get.put(SharedprefsController());
  StatisticsController statisticsController =
  Get.put(StatisticsController());

  @override
  Widget build(BuildContext context) {
    sharedprefsController.Sharedprefs();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.green.shade400,
        centerTitle: true,
        title: Obx(
            (){
              return Text('Monthly income: ${statisticsController.monthlyIncome.value}');
            }
        )
        // automaticallyImplyLeading: false,
      ),

      body: Obx(() {
        if(statisticsController.Done2.value==true) {
          return ListView.builder(
            scrollDirection: Axis.vertical,
            itemCount: statisticsController.statistics.value.length,
            itemBuilder: (BuildContext context,int i) {



              return Container(
                height: 200,
                margin: EdgeInsets.all(10),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(

                 
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.green
                  )
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Row(
                              children: [
                                Text('Date: ',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                                Text('${statisticsController.statistics[i]['Date']}',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                              ],
                            ),
                            Row(
                              children: [
                                Text('WaiterId: ',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                                Text('${statisticsController.statistics[i]['WaiterId']}',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                              ],
                            ),
                            Row(
                              children: [
                                Text('DeliveryId: ',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                                Text('${statisticsController.statistics[i]['DeliveryId']}',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                              ],
                            ),
                            Row(
                              children: [
                                Text('Delivered: ',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                                Text('${statisticsController.statistics[i]['Delivered']}',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                              ],
                            ),

                          ],
                        ),

                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Row(
                              children: [
                                Text('Id: ',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                                Text('${statisticsController.statistics[i]['id']}',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                              ],
                            ),
                            Row(
                              children: [
                                Text('CookId: ',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                                Text('${statisticsController.statistics[i]['CookId']}',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                              ],
                            ),
                            Row(
                              children: [
                                Text('AddressId: ',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                                Text('${statisticsController.statistics[i]['AddressId']}',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                              ],
                            ),
                            Row(
                              children: [
                                Text('Price: ',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                                Text('${statisticsController.statistics[i]['Price']}',
                                    style: TextStyle(color: Colors.green.shade400,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                              ],
                            ),



                          ],
                        )


                      ],
                    ),
                    Text('${statisticsController.statistics[i]['Type']}',
                        style: TextStyle(color: Colors.green.shade400,
                            fontWeight: FontWeight.w700,
                            fontSize: 20)),
                  ],
                ),
              );
            }
        );
        } else {
          statisticsController.viewStatistics();
            return Center(
              child: CircularProgressIndicator(
                  color: Colors.green, backgroundColor: Colors.yellow),
            );
          }
        })
    );
  }
}
