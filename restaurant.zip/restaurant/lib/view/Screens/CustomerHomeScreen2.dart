import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:restaurant/controllers/SharedprefsController.dart';
import 'package:get/get.dart';

class CustomerHomeScreen2 extends StatelessWidget{

  SharedprefsController  sharedprefsController=Get.put(SharedprefsController());

  CustomerHomeScreen2({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Column(
          children: [
            Obx((){
              sharedprefsController.Sharedprefs();
              if(sharedprefsController.Done.value==true)
              return Text('${sharedprefsController.prefs?.get('firstname')}');
              else
                return Text('data');

            }),
            ElevatedButton(onPressed: (){
              Get.toNamed('BossTablesScreen');
            }, child: Text('here'))
          ],
        ),
      ),
    );
  }

}