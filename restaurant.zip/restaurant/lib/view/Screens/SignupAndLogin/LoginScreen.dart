
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant/view/Widgets/InputTextFormField.dart';
import 'package:restaurant/controllers/SignupLogin/LoginController.dart';

import '../CustomerHomeScreen2.dart';

class LoginScreen extends StatelessWidget {
  final formKey = GlobalKey<FormState>();
  LoginController loginController = Get.put(LoginController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            top: 0,
            right: 0,
            left: 0,
            child: Container(
              height: MediaQuery. of(context). size. height/2,
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('assets/loginscreen.jpg'),
                      fit: BoxFit.fill)),
              child: Container(
                padding: const EdgeInsets.only(top: 200, left: 20),
                color: Colors.green.withOpacity(.60),
                child: Column(

                  children: [
                    SizedBox(
                      height: 15,
                    ),
                    Row(
                      children: [


                           Text(
                            'Welcome to ',
                            style: TextStyle(
                                fontSize: 30,
                                color: Colors.white,
                                fontWeight: FontWeight.w900),
                          ),
                           Stack(
                             children: [
                               Text(
                                'Easy Eat',
                                style: TextStyle(
                                    fontSize: 30,
                                    letterSpacing: 1,



                                    foreground: Paint()
                                      ..style = PaintingStyle.stroke
                                      ..strokeWidth = 4
                                      ..color = Colors.white,


                                    fontWeight: FontWeight.w700),
                          ),
                               Text(
                                 'Easy Eat',
                                 style: TextStyle(
                                     letterSpacing: 1,

                                     fontSize: 30,
                                     color: Colors.yellow.shade600,

                                     fontWeight: FontWeight.w700),
                               ),
                             ],
                           ),

                      ],
                    ),

                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: 550,
            right: 0,
            left: 0,
            child: Center(
              child: Container(
                height: 90,
                width: 90,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(50),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black.withOpacity(.3),
                          spreadRadius: 1.5,
                          blurRadius: 10,
                          offset: Offset(0, 1))
                    ]),
              ),
            ),
          ),
          Positioned(
            top: 270,
            child: Container(
              height: 320,
              width: MediaQuery.of(context).size.width - 40,
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 15,
                      spreadRadius: 5,
                    ),
                  ]),
              child: Column(
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(8, 16, 8, 0),
                    child: Text(
                      "LOGIN",
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: Colors.green,
                          letterSpacing: 3),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 3),
                    height: 4,
                    width: 70,
                    color: Colors.yellow.shade600,
                  ),
                  Form(
                    key: formKey,
                    child: Column(
                      children: [
                        Container(
                          margin: EdgeInsets.fromLTRB(25, 25, 25, 25),
                          height: 80,
                          child: InputTextFormField(loginController.EmailController,
                              "Email", "EmailValidator"),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(25, 0, 25, 25),
                          height: 80,
                          child: InputTextFormField(loginController.PasswordController,
                              "Password", "PasswordValidator"),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
          Positioned(
            top: 550,
            right: 0,
            left: 0,
            child: Center(
              child: Container(
                height: 90,
                width: 90,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(50),
                ),
                child: GestureDetector(
                  child: Container(
                    margin: EdgeInsets.all(15),
                    decoration: BoxDecoration(
                        color: Colors.green.shade400,
                        borderRadius: BorderRadius.circular(50),
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black.withOpacity(.3),
                              spreadRadius: 1,
                              blurRadius: 1,
                              offset: Offset(0, 1))
                        ]),
                    child: Icon(
                      Icons.arrow_forward,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
                  onTap: () {
                    if (formKey.currentState!.validate()) {
                      loginController.Login();

                    }
                  },
                ),
              ),
            ),
          ),
          Positioned(
            right: 0,
            left: 0,
            top: MediaQuery.of(context).size.height - 70,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Dont have an acount?',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 1),
                ),
                TextButton(
                  onPressed: () {
                    Get.toNamed('/CustomerSignupScreen');
                  },
                  child: const Text(
                    'Sign up',
                    style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                        color: Colors.green,),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
