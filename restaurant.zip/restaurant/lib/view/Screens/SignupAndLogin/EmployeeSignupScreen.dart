import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:restaurant/controllers/SignupLogin/EmployeeSignupController.dart';

import 'package:restaurant/view/Widgets/InputTextFormField.dart';
import 'package:restaurant/controllers/RadioController.dart';
String Role='waiter';
class EmployeeSignupScreen extends StatelessWidget {

  EmployeeSignupController employeeSignupController =
  Get.put(EmployeeSignupController());
  RadioPickerController radioPickerController =
  Get.put(RadioPickerController());

  final formKey = GlobalKey<FormState>();
  var Role='waiter';
  var groupValue;




  @override
  Widget build(BuildContext context) {

    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage(
              'assets/loginscreen.jpg',
            ),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.linearToSrgbGamma()),
      ),
      child: Container(
        color: Colors.yellow.shade600.withOpacity(.20),
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.green.shade400,

            centerTitle: true,
            title: Text('Register an employee'),

          ),
          backgroundColor: Colors.transparent,
          body: Form(
            key: formKey,
            child: ListView(
              physics: NeverScrollableScrollPhysics(),
              children: [
                SizedBox(
                  height: 20,
                ),
                Container(
                  margin: EdgeInsets.all(10),
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          height: 80,
                          child: InputTextFormField(
                              employeeSignupController.FirstNameController,
                              'FirstName',
                              'NameValidator'),
                        ),
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          height: 80,
                          child: InputTextFormField(
                              employeeSignupController.LastNameController,
                              'LastName',
                              'NameValidator'),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 80,
                  margin: EdgeInsets.all(10),
                  child: InputTextFormField(
                      employeeSignupController.EmailController,
                      'Email',
                      'EmailValidator'),
                ),
                Container(
                  height: 80,
                  margin: EdgeInsets.all(10),
                  child: InputTextFormField(
                      employeeSignupController.PasswordController,
                      'Password',
                      'PasswordValidator'),
                ),
                Container(
                  height: 80,
                  margin: EdgeInsets.all(10),
                  child: InputTextFormField(
                      employeeSignupController.SalaryController,
                      'Salary',
                      'NumberValidator'),
                ),

                Obx(() {



                    return Container(
                      margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,

                        children: [
                          if(radioPickerController.selectedRole.value=='Waiter')
                            ElevatedButton(
                                style: ButtonStyle(
                                    shape: MaterialStatePropertyAll(CircleBorder()),
                                    padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                    backgroundColor: MaterialStatePropertyAll(Colors.green.shade400)
                                ),
                                onPressed: () {
                                  radioPickerController.selectedRole.value='Waiter';
                                  radioPickerController.pickRadio('Waiter');
                                },
                                child: Text('Waiter',
                                  style: TextStyle(color: Colors.white,
                                    fontSize: Checkbox.width-3,
                                    fontWeight: FontWeight.w800,
                                  ),
                                )
                            )
                          else
                            ElevatedButton(
                              style: ButtonStyle(
                                shape: MaterialStatePropertyAll(CircleBorder()),
                                padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                backgroundColor: MaterialStatePropertyAll(Colors.white)
                              ),
                                onPressed: () {
                                  radioPickerController.selectedRole.value='Waiter';
                                  radioPickerController.pickRadio('Waiter');
                                },
                                child: Text('Waiter',
                                style: TextStyle(color: Colors.green.shade400,
                                fontSize: Checkbox.width-3,
                                fontWeight: FontWeight.w800,
                                ),
                                )
                            ) ,
                          if(radioPickerController.selectedRole.value=='Cook')
                            ElevatedButton(
                                style: ButtonStyle(
                                    shape: MaterialStatePropertyAll(CircleBorder()),
                                    padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                    backgroundColor: MaterialStatePropertyAll(Colors.green.shade400)
                                ),
                                onPressed: () {
                                  radioPickerController.selectedRole.value='Cook';
                                  radioPickerController.pickRadio('Cook');
                                },
                                child: Text('Cook',
                                  style: TextStyle(color: Colors.white,
                                    fontSize: Checkbox.width-3,
                                    fontWeight: FontWeight.w800,
                                  ),
                                )
                            )
                          else
                            ElevatedButton(
                                style: ButtonStyle(
                                    shape: MaterialStatePropertyAll(CircleBorder()),
                                    padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                    backgroundColor: MaterialStatePropertyAll(Colors.white)
                                ),
                                onPressed: () {
                                  radioPickerController.selectedRole.value='Cook';
                                  radioPickerController.pickRadio('Cook');
                                },
                                child: Text('Cook',
                                  style: TextStyle(color: Colors.green.shade400,
                                    fontSize: Checkbox.width-3,
                                    fontWeight: FontWeight.w800,
                                  ),
                                )
                            ) ,
                          if(radioPickerController.selectedRole.value=='Delivery')
                            ElevatedButton(
                                style: ButtonStyle(
                                    shape: MaterialStatePropertyAll(CircleBorder()),
                                    padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                    backgroundColor: MaterialStatePropertyAll(Colors.green.shade400)
                                ),
                                onPressed: () {
                                  radioPickerController.selectedRole.value='Delivery';
                                  radioPickerController.pickRadio('Delivery');
                                },
                                child: Text('Delivery',
                                  style: TextStyle(color: Colors.white,
                                    fontSize: Checkbox.width-3,
                                    fontWeight: FontWeight.w800,
                                  ),
                                )
                            )
                          else
                            ElevatedButton(
                                style: ButtonStyle(
                                    shape: MaterialStatePropertyAll(CircleBorder()),
                                    padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                    backgroundColor: MaterialStatePropertyAll(Colors.white)
                                ),
                                onPressed: () {
                                  radioPickerController.selectedRole.value='Delivery';
                                  radioPickerController.pickRadio('Delivery');
                                },
                                child: Text('Delivery',
                                  style: TextStyle(color: Colors.green.shade400,
                                    fontSize: Checkbox.width-3,
                                    fontWeight: FontWeight.w800,
                                  ),
                                )
                            ) ,
                          if(radioPickerController.selectedRole.value=='Parking')
                            ElevatedButton(
                                style: ButtonStyle(
                                    shape: MaterialStatePropertyAll(CircleBorder()),
                                    padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                    backgroundColor: MaterialStatePropertyAll(Colors.green.shade400)
                                ),
                                onPressed: () {
                                  radioPickerController.selectedRole.value='Parking';
                                  radioPickerController.pickRadio('Parking');
                                },
                                child: Text('Parking',
                                  style: TextStyle(color: Colors.white,
                                    fontSize: Checkbox.width-3,
                                    fontWeight: FontWeight.w800,
                                  ),
                                )
                            )
                          else
                            ElevatedButton(
                                style: ButtonStyle(
                                    shape: MaterialStatePropertyAll(CircleBorder()),
                                    padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                    backgroundColor: MaterialStatePropertyAll(Colors.white)
                                ),
                                onPressed: () {

                                  radioPickerController.selectedRole.value='Parking';
                                  radioPickerController.pickRadio('Parking');
                                },
                                child: Text('Parking',
                                  style: TextStyle(color: Colors.green.shade400,
                                    fontSize: Checkbox.width-3,
                                    fontWeight: FontWeight.w800,
                                  ),
                                )
                            ) ,





                      ],),
                    );
    }),
                Container(
                  margin: EdgeInsets.fromLTRB(130, 50, 130  , 10),
                  child: ElevatedButton(
                    style: ButtonStyle(
                        fixedSize: MaterialStatePropertyAll(Size(0, 70)),
                        backgroundColor: MaterialStatePropertyAll(Colors.green.shade400),
                        padding: MaterialStatePropertyAll(EdgeInsets.all(11)),
                        shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(80)))),
                    onPressed: () {

                      if (formKey.currentState!.validate()) {

                        employeeSignupController.Emp_Signup();





                      }
                    },
                    child: Text('Sign up',
                        style: TextStyle(
                          fontSize: 20,
                        )),
                  ),
                ),




              ],
            ),
          ),
        ),
      ),
    );
  }
}
