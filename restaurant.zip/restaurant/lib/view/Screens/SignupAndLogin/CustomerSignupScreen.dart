import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import 'package:restaurant/view/Widgets/InputTextFormField.dart';
import 'package:restaurant/controllers/SignupLogin/CustomerSignupController.dart';
import 'package:restaurant/controllers/DatePickerController.dart';

class CustomerSignupScreen extends StatelessWidget {
  final formKey = GlobalKey<FormState>();
  CustomerSignupController customerSignupController =
      Get.put(CustomerSignupController());
  DatePickerController datePickerController = Get.put(DatePickerController());

  CustomerSignupScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
            image: AssetImage(
              'assets/loginscreen.jpg',
            ),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.linearToSrgbGamma()),
      ),
      child: Container(
        color: Colors.yellow.shade600.withOpacity(.20),
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.green.shade400,
            shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(80),
              bottomRight: Radius.circular(80),
            )),
            centerTitle: true,
            title: const Text('Register to Easy Eat'),
            automaticallyImplyLeading: false,
          ),
          backgroundColor: Colors.transparent,
          body: Form(
            key: formKey,
            child: ListView(
              physics: const NeverScrollableScrollPhysics(),
              children: [
                const SizedBox(
                  height: 20,
                ),
                Container(
                  margin: EdgeInsets.all(10),
                  child: Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 80,
                          child: InputTextFormField(
                              customerSignupController.FirstNameController,
                              'FirstName',
                              'NameValidator'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: SizedBox(
                          height: 80,
                          child: InputTextFormField(
                              customerSignupController.LastNameController,
                              'LastName',
                              'NameValidator'),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 80,
                  margin: EdgeInsets.all(10),
                  child: InputTextFormField(
                      customerSignupController.EmailController,
                      'Email',
                      'EmailValidator'),
                ),
                Container(
                  height: 80,
                  margin: EdgeInsets.all(10),
                  child: InputTextFormField(
                      customerSignupController.PasswordController,
                      'Password',
                      'PasswordValidator'),
                ),
                Container(
                  height: 80,
                  margin: EdgeInsets.all(10),
                  child: InputTextFormField(
                      customerSignupController.NumberController,
                      'Number',
                      'PhoneNumberValidator'),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(70, 10, 70, 10),
                  child: ElevatedButton(
                    style: ButtonStyle(

                        backgroundColor: MaterialStatePropertyAll(Colors.white),
                        padding: MaterialStatePropertyAll(EdgeInsets.all(13)),
                        shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(80),
                        ))),
                    onPressed: () {
                      datePickerController.pickDate(context);
                    },
                    child: Obx(() {
                      if (datePickerController.selectedDate.value.day ==
                              DateTime.now().day &&
                          datePickerController.selectedDate.value.month ==
                              DateTime.now().month &&
                          datePickerController.selectedDate.value.year ==
                              DateTime.now().year)
                        return Text(
                          'Enter your birthday',
                          style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w600,
                              color: Colors.green.shade400),
                        );
                      else
                        return Text(
                          'Selected Date: '
                          '${datePickerController.selectedDate.value.day}'
                          '-${datePickerController.selectedDate.value.month}'
                          '-${datePickerController.selectedDate.value.year}',
                          style: TextStyle(
                            fontSize: 17,
                            color: Colors.green,
                            fontWeight: FontWeight.w600,
                          ),
                        );
                    }),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(130, 10, 130  , 10),
                  child: ElevatedButton(
                    style: ButtonStyle(
                        fixedSize: MaterialStatePropertyAll(Size(0, 70)),
                        backgroundColor: MaterialStatePropertyAll(Colors.green.shade400),
                        padding: MaterialStatePropertyAll(EdgeInsets.all(11)),
                        shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(80)))),
                    onPressed: () {
                      if (formKey.currentState!.validate()) {
                        print(datePickerController.selectedDate.value);
                        customerSignupController.BirthdayController.text =DateFormat('yyyy-MM-dd').format(datePickerController.selectedDate.value);
                        customerSignupController.Cus_Signup();
                      }
                    },
                    child: Text('Sign up',
                        style: TextStyle(
                          fontSize: 20,
                        )),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
