
import 'package:flutter/material.dart';
import 'package:get/get.dart';


import 'package:restaurant/controllers/Profile/EmployeeProfileController.dart';

import 'package:restaurant/view/Widgets/InputTextFormField.dart';

class EmployeeProfileScreen extends StatelessWidget {

  final formKey = GlobalKey<FormState>();
  EmployeeProfileController profileController = Get.put(EmployeeProfileController());

  var RoleName;

  EmployeeProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.green.shade400,
      ),
      body: Obx(() {
        profileController.ShowProfile();

        if (profileController.Role.value == 1) RoleName = 'Boss';
        if (profileController.Role.value == 2) RoleName = 'Waiter';
        if (profileController.Role.value == 3) RoleName = 'Cook';
        if (profileController.Role.value == 4) RoleName = 'Delivery';
        if (profileController.Role.value == 5) RoleName = 'Parking';
        if(profileController.Done==true) {
          return Stack(
          children: [
            Positioned(
              top: MediaQuery.of(context).size.height / 7,
              right: 0,
              left: 0,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        profileController.FirstName.value,
                        style: TextStyle(
                            fontSize: 50,
                            color: Colors.green.shade400,
                            fontWeight: FontWeight.w600),
                      ),
                      Text(
                        ' ${profileController.LastName.value}',
                        style: TextStyle(
                            fontSize: 50,
                            color: Colors.green.shade400,
                            fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width / 1.5,
                    height: 6,
                    decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        color: Colors.yellow.shade600),
                  )
                ],
              ),
            ),

            //background
            Positioned(
              bottom: 0,
              right: 0,
              left: 0,
              child: SizedBox(
                height: MediaQuery.of(context).size.height / 1.8,
                child: Container(
                  decoration: BoxDecoration(
                      image: const DecorationImage(
                          image: AssetImage('assets/loginscreen.jpg'),
                          fit: BoxFit.fill),
                      boxShadow: List.filled(
                          1,
                          BoxShadow(
                              color: Colors.green.shade700, blurRadius: 35)),
                      borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(40),
                          topRight: Radius.circular(40))),
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.green.withOpacity(.80),
                        borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(40),
                            topRight: Radius.circular(40))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                              width: 100,
                              height: 100,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                              ),
                              child: Column(
                                children: [
                                  const SizedBox(height: 10,),
                                  const Text(
                                    'Role',
                                    style: TextStyle(
                                      fontSize: 20,
                                     color: Colors.green,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(height: 10,),
                                  Container(
                                    height: 2,
                                    width: 80,
                                    color: Colors.yellow.shade600,
                                  ),
                                  const SizedBox(height: 10,),
                                  Text(
                                    RoleName,
                                    style: TextStyle(
                                      fontSize: 20,
                                      color: Colors.green,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Stack(
                              children: [
                                Container(
                                  width: 100,
                                  height: 100,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.white,
                                  ),
                                  child: Column(
                                    children: [
                                      const SizedBox(height: 10,),
                                      const Text(
                                        'Salary',
                                        style: TextStyle(
                                            fontSize: 20,
                                            color: Colors.green,
                                            fontWeight: FontWeight.w700),
                                      ),
                                      const SizedBox(height: 10,),
                                      Container(
                                        height: 2,
                                        width: 80,
                                        color: Colors.yellow.shade600,
                                      ),
                                      const SizedBox(height: 10,),
                                      Text(
                                        '${profileController.Salary.value}',
                                        style: TextStyle(
                                            fontSize: 20,
                                            color: Colors.green,
                                            fontWeight: FontWeight.w700),
                                      ),






                                    ],
                                  ),
                                ),
                                Positioned(
                                  bottom: 0,
                                  right:0,
                                  width: 20,
                                  height: 30,

                                  child: IconButton(
                                      onPressed: () {
                                        Get.dialog(AlertDialog(
                                          shape: const RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(30))),
                                          content: Container(
                                            width: 150,
                                            height: 102,
                                            child: Column(
                                              children: [
                                                Text('Salary',
                                                    style: TextStyle(
                                                        color: Colors.green,
                                                        fontWeight: FontWeight.w700,
                                                        fontSize: 20)),
                                                SizedBox(
                                                  height: 20,
                                                ),
                                                InputTextFormField(profileController.salary, 'Number', 'NumberValidator')
                                              ],
                                            ),
                                          ),
                                          actions: [
                                            TextButton(
                                                onPressed: () {

                                                  profileController.EditSalary(profileController.id.value, profileController.salary);
                                                  Get.back();


                                                },
                                                child: Text(
                                                  'Submit',
                                                  style: TextStyle(
                                                      color: Colors.yellow.shade600,
                                                      fontSize: 18,
                                                      fontWeight: FontWeight.w700),
                                                ))
                                          ],
                                        ),);
                                      },
                                      icon: Icon(
                                        Icons.edit,
                                        color: Colors.green.shade50,
                                      )),
                                ),
                              ],
                            ),

                          ],
                        ),


                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [

                            Container(
                              width: 100,
                              height: 100,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white,
                              ),
                              child: Column(children: [
                                const SizedBox(height: 10,),
                                Text(
                                  'Orders',
                                  style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.green,
                                      fontWeight: FontWeight.w700),
                                ),
                                Text(
                                  'Served',
                                  style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.green,
                                      fontWeight: FontWeight.w700),
                                ),
                                const SizedBox(height: 10,),
                                Container(
                                  height: 2,
                                  width: 80,
                                  color: Colors.yellow.shade600,
                                ),
                                const SizedBox(height: 10,),
                                Text(
                                  profileController.Served.value.toString(),
                                  style: TextStyle(
                                      fontSize: 20,
                                      color: Colors.green,
                                      fontWeight: FontWeight.w700),
                                ),
                              ],),
                            ),
                            Container(
                              width: 100,
                              height: 100,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white,
                              ),
                              child: Column(
                                children: [
                                  const SizedBox(height: 10,),
                                  Text(
                                    'Work',
                                    style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.green,
                                        fontWeight: FontWeight.w700),
                                  ),
                                  Text(
                                    'Time',
                                    style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.green,
                                        fontWeight: FontWeight.w700),
                                  ),
                                  const SizedBox(height: 10,),
                                  Container(
                                    height: 2,
                                    width: 80,
                                    color: Colors.yellow.shade600,
                                  ),
                                  const SizedBox(height: 10,),
                                  Text(
                                    '${profileController.WorkTime.value.toString()}m',
                                    style: TextStyle(
                                        fontSize: 20,
                                        color: Colors.green,
                                        fontWeight: FontWeight.w700),
                                  ),

                                ],
                              ),),


                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'Rate: ',
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700),
                            ),
                            Text(
                              ' ' + profileController.Rate.value.toString(),
                              style: TextStyle(
                                  fontSize: 25,
                                  color: Colors.yellow.shade600,
                                  fontWeight: FontWeight.w700),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
        } else
          return Center(child: CircularProgressIndicator(color: Colors.green,backgroundColor: Colors.yellow),);
      }),
    );
  }
}
