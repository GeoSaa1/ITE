
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant/controllers/Profile/CustomerProfileController.dart';




import 'package:restaurant/view/Widgets/InputTextFormField.dart';



class CustomerProfileScreen extends StatelessWidget {

  final formKey = GlobalKey<FormState>();
  CustomerProfileController CustomerprofileController = Get.put(CustomerProfileController());


  CustomerProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.green.shade400,
      ),
      body: Obx(() {

        CustomerprofileController.ShowProfile();
        if(CustomerprofileController.Done.value==true) {
          return Stack(
            children: [
              Positioned(
                top: MediaQuery.of(context).size.height / 7,
                right: 0,
                left: 0,
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          CustomerprofileController.FirstName.value,
                          style: TextStyle(
                              fontSize: 35,
                              color: Colors.green.shade400,
                              fontWeight: FontWeight.w600),
                        ),
                        Text(
                          ' ${CustomerprofileController.LastName.value}',
                          style: TextStyle(
                              fontSize: 35,
                              color: Colors.green.shade400,
                              fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width / 1.5,
                      height: 6,
                      decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          color: Colors.yellow.shade600),
                    )
                  ],
                ),
              ),

              //background
              Positioned(
                bottom: 0,
                right: 0,
                left: 0,
                child: SizedBox(
                  height: MediaQuery.of(context).size.height / 1.8,
                  child: Container(
                    decoration: BoxDecoration(
                        image: const DecorationImage(
                            image: AssetImage('assets/loginscreen.jpg'),
                            fit: BoxFit.fill),
                        boxShadow: List.filled(
                            1,
                            BoxShadow(
                                color: Colors.green.shade700, blurRadius: 35)),
                        borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(40),
                            topRight: Radius.circular(40))),
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.green.withOpacity(.80),
                          borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(40),
                              topRight: Radius.circular(40))),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Container(
                                width: 100,
                                height: 100,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                ),
                                child: Column(
                                  children: [
                                    const SizedBox(height: 10,),
                                    const Text(
                                      'Visited',
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.green,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    const Text(
                                      'Times',
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.green,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    const SizedBox(height: 10,),
                                    Container(
                                      height: 2,
                                      width: 80,
                                      color: Colors.yellow.shade600,
                                    ),
                                    const SizedBox(height: 10,),
                                    Text(
                                      '${CustomerprofileController.Visited.value}',
                                      style: TextStyle(
                                        fontSize: 20,
                                        color: Colors.green,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                width: 100,
                                height: 100,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                ),
                                child: Column(
                                  children: [
                                    const SizedBox(height: 10,),
                                    const Text(
                                      'Loyalty',
                                      style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.green,
                                          fontWeight: FontWeight.w700),
                                    ),
                                    const Text(
                                      'Points',
                                      style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.green,
                                          fontWeight: FontWeight.w700),
                                    ),
                                    const SizedBox(height: 10,),
                                    Container(
                                      height: 2,
                                      width: 80,
                                      color: Colors.yellow.shade600,
                                    ),
                                    const SizedBox(height: 10,),
                                    Text(
                                      CustomerprofileController.LoyaltyPoints.value.toString(),
                                      style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.green,
                                          fontWeight: FontWeight.w700),
                                    ),






                                  ],
                                ),
                              ),

                            ],
                          ),


                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [

                              Container(
                                width: 100,
                                height: 100,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                ),
                                child: Column(children: [
                                  const SizedBox(height: 10,),
                                  Text(
                                    'Canceled',
                                    style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.green,
                                        fontWeight: FontWeight.w700),
                                  ),
                                  Text(
                                    'Reservations',
                                    style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.green,
                                        fontWeight: FontWeight.w700),
                                  ),
                                  const SizedBox(height: 10,),
                                  Container(
                                    height: 2,
                                    width: 80,
                                    color: Colors.yellow.shade600,
                                  ),
                                  const SizedBox(height: 10,),
                                  Text(
                                    CustomerprofileController.Canceled.value.toString(),
                                    style: TextStyle(
                                        fontSize: 20,
                                        color: Colors.green,
                                        fontWeight: FontWeight.w700),
                                  ),
                                ],),
                              ),
                              Container(
                                width: 100,
                                height: 100,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                ),
                                child: Column(
                                  children: [
                                    const SizedBox(height: 10,),
                                    Text(
                                      'Didn${"'"}t',
                                      style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.green,
                                          fontWeight: FontWeight.w700),
                                    ),
                                    Text(
                                      'come',
                                      style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.green,
                                          fontWeight: FontWeight.w700),
                                    ),
                                    const SizedBox(height: 10,),
                                    Container(
                                      height: 2,
                                      width: 80,
                                      color: Colors.yellow.shade600,
                                    ),
                                    const SizedBox(height: 10,),
                                    Text(
                                      CustomerprofileController.DidntCome.value.toString(),
                                      style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.green,
                                          fontWeight: FontWeight.w700),
                                    ),

                                  ],
                                ),),


                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Phone Number: ',
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700),
                              ),
                              Text(
                                CustomerprofileController.Number.value.toString(),
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.yellow.shade600,
                                    fontWeight: FontWeight.w700),
                              )
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Birthday: ',
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700),
                              ),
                              Text(
                                CustomerprofileController.Birthday.value.toString(),
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.yellow.shade600,
                                    fontWeight: FontWeight.w700),
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          );
        } else
          return Center(child: CircularProgressIndicator(color: Colors.green,backgroundColor: Colors.yellow),);
      }),
    );
  }
}
