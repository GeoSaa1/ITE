import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:restaurant/controllers/SharedprefsController.dart';
import 'package:restaurant/controllers/SignupLogin/LogOutController.dart';
import '../Models/Card_Info.dart';
import '../Widgets/Cards.dart';

class WaiterHomeScreen extends StatelessWidget{
  final List<CardsInfo> loadedCards = [

    CardsInfo(
      id: '1',
      title: 'Meals',
      imageURL: 'assets/Meals2.png',
      pageURL: '/MealsScreen',
    ),
    CardsInfo(
      id: '2',
      title: 'Serve',
      imageURL: 'assets/serve.jpg',
      pageURL: '/ServeScreen',
    ),
    CardsInfo(
      id: '3',
      title: 'Reservations',
      imageURL: 'assets/Reservations.jpg',
      pageURL: '/ViewReservationScreen',
    ),
    CardsInfo(
      id: '4',
      title: 'Check',
      imageURL: 'assets/Check.jpg',
      pageURL: '/CheckReservationsScreen',
    ),
    CardsInfo(
      id: '5',
      title: 'Orders',
      imageURL: 'assets/Meals.png',
      pageURL: '/WaiterOrderScreen',
    ),
    CardsInfo(
      id: '6',
      title: 'Delivery',
      imageURL: 'assets/delivery.jpg',
      pageURL: '/DeliveryScreen',
    ),




  ];
  SharedprefsController sharedprefsController =
  Get.put(SharedprefsController());
  LogOutController logOutController = Get.put(LogOutController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.green.shade400,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              bottomRight: Radius.circular(80),
            )),
        centerTitle: true,
        title: Text('Home Page'),
        // automaticallyImplyLeading: false,
      ),
      drawer: Drawer(
        child: Column(children: [
          Obx(() {
            if (sharedprefsController.Done.value == true) {
              return UserAccountsDrawerHeader(
                  decoration: BoxDecoration(
                      color: Colors.green.shade400,
                      borderRadius: BorderRadius.only(bottomRight: Radius.circular(20),bottomLeft: Radius.circular(20))),
                  accountName: Text(
                    "${sharedprefsController.prefs!.getString('firstname')}" +
                        ' ' +
                        '${sharedprefsController.prefs?.getString('lastname')}',
                    style: TextStyle(fontSize: 25,color: Colors.white),
                  ),
                  accountEmail: Text(
                    "${sharedprefsController.prefs!.getString('email')}",
                    style: TextStyle(fontSize: 17,color: Colors.yellow.shade600),
                  ));
            } else {
              return Container(
                  height: 190,

                  child: Center(
                    child: CircularProgressIndicator(
                        color: Colors.green, backgroundColor: Colors.yellow),
                  ));
            }
          }),
          ListTile(

            title: Text("Profile",
              style: TextStyle(fontSize: 17,color: Colors.green.shade400),
            ),
            leading: Icon(
              Icons.man,
              color: Colors.green.shade400,
            ),
            onTap: () {

              Get.toNamed('EmployeeProfileScreen');
            },
          ),
          ListTile(

            title: Text("Statistics",
              style: TextStyle(fontSize: 17,color: Colors.green.shade400),
            ),
            leading: Icon(
              Icons.monetization_on_outlined,
              color: Colors.green.shade400,
            ),
            onTap: () {

              Get.toNamed('StatisticsScreen');
            },
          ),
          ListTile(

            title: Text("Waiting List",
              style: TextStyle(fontSize: 17,color: Colors.green.shade400),
            ),
            leading: Icon(
              Icons.list_alt_outlined,
              color: Colors.green.shade400,
            ),
            onTap: () {

              Get.toNamed('WaitingListScreen');
            },
          ),
          ListTile(

            title: Text("Logout",
              style: TextStyle(fontSize: 17,color: Colors.green.shade400),
            ),
            leading: Icon(
              Icons.exit_to_app,
              color: Colors.green.shade400,
            ),
            onTap: () {
              logOutController.logOut();
              Get.offNamed('LoginScreen');
            },
          ),

        ]),


      ),
      body: GridView.builder(
        physics: BouncingScrollPhysics(),
        itemCount: loadedCards.length,
        itemBuilder: (context,i) =>
            Cards(
              loadedCards[i].id,
              loadedCards[i].title,
              loadedCards[i].imageURL,
              loadedCards[i].pageURL,
            ),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(

          crossAxisCount: 2,
          childAspectRatio: 1.1,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
        ),
      ),
    );
  }
}



