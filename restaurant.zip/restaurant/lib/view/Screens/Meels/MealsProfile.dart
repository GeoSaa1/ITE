import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:restaurant/controllers/Meals/MealController.dart';
import 'package:restaurant/controllers/SharedprefsController.dart';

class MealProfile extends StatelessWidget {
  MealController mealController=Get.put(MealController());
  SharedprefsController sharedprefsController=Get.put(SharedprefsController());

  // final String id;
  // final String name;
  // final double price;
  // final double LPprice;
  // final double LoyaltyPoints;
  // final String category;
  // final String description;
  // final String imageURL;
  //
  // MealProfile(
  //     this.id,
  //     this.name,
  //     this.price,
  //     this.LPprice,
  //     this.LoyaltyPoints,
  //     this.category,
  //     this.description,
  //     this.imageURL,
  //     );

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        appBar: AppBar( backgroundColor: Colors.green,

        ),
      body: Obx((){
        mealController.getMeal(sharedprefsController.prefs!.getString('MealId'));
        return Padding(
          padding: EdgeInsets.only(top: 5),
          child:
          Column(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 25.0),
                    child: ListView(
                      children: [
                    if(mealController.meal.value['Category']=='Meals')
                        Image.asset(
                          'assets/Pizza.jpg',
                          height: 220,
                        )
                    else if(mealController.meal.value['Category']=='Salads')
                      Image.asset(

                            'assets/cesersalad.jpg'

                            ,
                        height: 220,
                      )
                    else
                      Image.asset(

                            'assets/drinks.jpg',
                        height: 220,
                      ),
                        SizedBox(height: 25,),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Icon(
                              Icons.price_change_rounded,
                              color: Colors.green,
                            ),
                            SizedBox(width: 5,),

                            Text('price:',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text('${mealController.meal.value['Price']}',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            // SizedBox(width: 7,),

                            Container(
                              padding: EdgeInsets.only(left: 10),
                              margin: EdgeInsets.all(10),
                              child: Row(
                                children: [
                                  Text('LPprice: ',
                                    style:
                                    TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),),
                                  Text(
                                    '${mealController.meal.value['LPPrice']}',
                                      style:
                                      TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                      ),
                                  SizedBox(width: 20,),
                                  Text(
                                    'LoyaltyPoints:',
                                    style:
                                    TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    '${mealController.meal.value['LoyaltyPoints']}',
                                      style:
                                  TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),

                                  )

                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 8,),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('${mealController.meal.value['Name']}',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 28
                              ),
                            ),
                            Text('Rate: ${mealController.meal.value['Rate']}',
                              style: TextStyle(
                                color: Colors.grey,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 17
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: 30,),

                        Text(
                          "description",
                          style: TextStyle(
                              color: Colors.grey[900],
                              fontWeight: FontWeight.bold,
                              fontSize: 19
                          ),
                        ),
                        SizedBox(height: 10,),
                        Text(
                          '${mealController.meal.value['Description']}',
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 17,
                            height: 2,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              ]
          ),
        );
      })
    );
  }
}
