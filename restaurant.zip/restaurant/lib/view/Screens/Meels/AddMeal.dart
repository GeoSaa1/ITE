import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:restaurant/controllers/Meals/AddMealController.dart';
import 'package:restaurant/view/Widgets/InputTextFormField.dart';


class AddMeal extends StatelessWidget {
  final formKey = GlobalKey<FormState>();
  AddMealController addMealController = Get.put(AddMealController());

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage(
              'assets/loginscreen.jpg',
            ),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.linearToSrgbGamma()),
      ),
      child: Container(
        color: Colors.yellow.shade600.withOpacity(.20),
        child: Scaffold(
          appBar: AppBar(

            backgroundColor: Colors.green.shade400,

            centerTitle: true,
            title: Text('Add Meal'),

          ),
          // backgroundColor: Colors.transparent,
          body: Form(
            key: formKey,
            child: ListView(
              physics: NeverScrollableScrollPhysics(),
              children: [
                SizedBox(
                  height: 20,
                ),
                Container(
                  height: 80,
                  margin: EdgeInsets.all(10),
                  child: InputTextFormField(
                      addMealController.NameController,
                      'Name',
                      'NameValidator'),
                 ),
                Container(
                  margin: EdgeInsets.all(10),
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          height: 80,
                          child: InputTextFormField(
                              addMealController.PriceController,
                              'Price',
                              'NumberValidator'),
                        ),
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          height: 80,
                          child: InputTextFormField(
                              addMealController.LPPriceController,
                              'LPPrice',
                              'NumberValidator'),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 80,
                  margin: EdgeInsets.all(10),
                  child: InputTextFormField(
                      addMealController.LoyaltyPointsController,
                      'LoyaltyPoints',
                      'NumberValidator'),
                ),
                Container(
                  height: 80,
                  margin: EdgeInsets.all(10),
                  child: InputTextFormField(
                      addMealController.DescriptionController,
                      'Description',
                      'NameValidator'),
                ),
                Obx(() {
                  return Container(
                    margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        if(addMealController.cat.value=='Meals')
                          ElevatedButton(
                              style: ButtonStyle(
                                  shape: MaterialStatePropertyAll(CircleBorder()),
                                  padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                  backgroundColor: MaterialStatePropertyAll(Colors.green.shade400)
                              ),
                              onPressed: () {
                                addMealController.cat.value='Meals';
                              },
                              child: Text('Meals',
                                style: TextStyle(color: Colors.yellow.shade100,
                                  fontSize: Checkbox.width-3,
                                  fontWeight: FontWeight.w800,
                                ),
                              )
                          )
                        else
                          ElevatedButton(
                              style: ButtonStyle(
                                  shape: MaterialStatePropertyAll(CircleBorder()),
                                  padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                  backgroundColor: MaterialStatePropertyAll(Colors.yellow.shade100)
                              ),
                              onPressed: () {
                                addMealController.cat.value='Meals';
                              },
                              child: Text('Meals',
                                style: TextStyle(color: Colors.green.shade400,
                                  fontSize: Checkbox.width-3,
                                  fontWeight: FontWeight.w800,
                                ),
                              )
                          ) ,
                        if(addMealController.cat.value=='Salads')
                          ElevatedButton(
                              style: ButtonStyle(
                                  shape: MaterialStatePropertyAll(CircleBorder()),
                                  padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                  backgroundColor: MaterialStatePropertyAll(Colors.green.shade400)
                              ),
                              onPressed: () {
                                addMealController.cat.value='Salads';
                              },
                              child: Text('Salads',
                                style: TextStyle(color: Colors.yellow.shade100,
                                  fontSize: Checkbox.width-3,
                                  fontWeight: FontWeight.w800,
                                ),
                              )
                          )
                        else
                          ElevatedButton(
                              style: ButtonStyle(
                                  shape: MaterialStatePropertyAll(CircleBorder()),
                                  padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                  backgroundColor: MaterialStatePropertyAll(Colors.yellow.shade100)
                              ),
                              onPressed: () {
                                addMealController.cat.value='Salads';
                              },
                              child: Text('Salads',
                                style: TextStyle(color: Colors.green.shade400,
                                  fontSize: Checkbox.width-3,
                                  fontWeight: FontWeight.w800,
                                ),
                              )
                          ) ,
                        if(addMealController.cat.value=='Drinks')
                          ElevatedButton(
                              style: ButtonStyle(
                                  shape: MaterialStatePropertyAll(CircleBorder()),
                                  padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                  backgroundColor: MaterialStatePropertyAll(Colors.green.shade400)
                              ),
                              onPressed: () {
                                addMealController.cat.value='Drinks';
                              },
                              child: Text('Drinks',
                                style: TextStyle(color: Colors.yellow.shade100,
                                  fontSize: Checkbox.width-3,
                                  fontWeight: FontWeight.w800,
                                ),
                              )
                          )
                        else
                          ElevatedButton(
                              style: ButtonStyle(
                                  shape: MaterialStatePropertyAll(CircleBorder()),
                                  padding: MaterialStatePropertyAll(EdgeInsets.all(20)),
                                  backgroundColor: MaterialStatePropertyAll(Colors.yellow.shade100)
                              ),
                              onPressed: () {
                                addMealController.cat.value='Drinks';
                              },
                              child: Text('Drinks',
                                style: TextStyle(color: Colors.green.shade400,
                                  fontSize: Checkbox.width-3,
                                  fontWeight: FontWeight.w800,
                                ),
                              )
                          ) ,
                      ],),
                  );
                }),
                Container(
                  padding: EdgeInsets.all(15),
                  margin: EdgeInsets.all(35),
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50)),
                          primary: Colors.green,),
                      onPressed: (){
            if (formKey.currentState!.validate()) {
            addMealController.addMeal();
                }

                      },
                      child: Text('Add Meal')
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
