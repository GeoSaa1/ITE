import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:restaurant/controllers/Meals/MealController.dart';
import 'package:restaurant/view/Widgets/MealInfo.dart';


class MealsScreen extends StatelessWidget {
  MealController mealController=Get.put(MealController());
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {},
      //   backgroundColor: Colors.green,
      //   child: Icon(Icons.shopping_cart),
      // ),
      appBar: AppBar(
        backgroundColor: Colors.green.shade400,
        title: Text('Meals'),

        actions: [
          IconButton(icon: Icon(Icons.add_circle),onPressed: (){
            Get.toNamed('AddMeal');
          })
        ],
      ),
      body: Obx((){
        if(mealController.Done.value==true) {

          return RefreshIndicator(
            color: Colors.yellow.shade400,
            backgroundColor: Colors.green.shade400,
            onRefresh: (){
              mealController.Done.value=false;
              return mealController.viewMenu();


            },
            child: ListView.builder(


              itemCount: mealController.meals.value.length,
              itemBuilder: (context, i)
              {
                if(mealController.meals.value[i]['Category'].toString()=='Meals')
                 return MealInfo(
                   mealController.meals.value[i]['id'].toString(),
                   mealController.meals.value[i]['Name'],
                   mealController.meals.value[i]['Price'],
                   mealController.meals.value[i]['LPPrice'],
                   mealController.meals.value[i]['LoyaltyPoints'],
                   mealController.meals.value[i]['Category'].toString(),
                   mealController.meals.value[i]['Description'].toString(),
                   'assets/Pizza.jpg',

                  );
                else if(mealController.meals.value[i]['Category'].toString()=='Salads')
                  return MealInfo(
                    mealController.meals.value[i]['id'].toString(),
                    mealController.meals.value[i]['Name'],
                    mealController.meals.value[i]['Price'],
                    mealController.meals.value[i]['LPPrice'],
                    mealController.meals.value[i]['LoyaltyPoints'],
                    mealController.meals.value[i]['Category'].toString(),
                    mealController.meals.value[i]['Description'].toString(),
                    'assets/cesersalad.jpg',


                  );
                else
                return MealInfo(
                mealController.meals.value[i]['id'].toString(),
                mealController.meals.value[i]['Name'],
                mealController.meals.value[i]['Price'],
                mealController.meals.value[i]['LPPrice'],
                mealController.meals.value[i]['LoyaltyPoints'],
                mealController.meals.value[i]['Category'].toString(),
                mealController.meals.value[i]['Description'].toString(),
              'assets/drinks.jpg',


                );



                },

            ),
          );
        }
        else {
          mealController.viewMenu();
          return CircularProgressIndicator(
            backgroundColor: Colors.green,
            color: Colors.yellow.shade600,
          );
        }
      }),
    );
  }
}
