import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant/view/Screens/SignupAndLogin/LoginScreen.dart';

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
     
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            Container(

              decoration: BoxDecoration(

                borderRadius: BorderRadius.circular(75), // Adjust the border radius according to your logo shape
              ),
              // You can replace this with your actual logo widget/image
              child: Image(
                  image: AssetImage('assets/EasyEat.png')
              ),
            ),
            SizedBox(height: 30), // Spacer between logo and button
            ElevatedButton(
              onPressed: () {
                Get.offNamed('/LoginScreen');

              },

              style: ElevatedButton.styleFrom(

                primary: Colors.yellow.shade600, 
                padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
              ),
              child: Text(
                'Start',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.green
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}