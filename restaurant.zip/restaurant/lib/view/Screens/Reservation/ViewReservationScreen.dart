import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:restaurant/controllers/Reservation/ReservationController.dart';
import 'package:restaurant/controllers/Serve/ServeController.dart';

import 'package:restaurant/controllers/DatePickerController.dart';

class ViewReservationScreen extends StatelessWidget {
  final formKey = GlobalKey<FormState>();
  ReservationController reservationController =
      Get.put(ReservationController());
  ServeController serveController =
  Get.put(ServeController());
  DatePickerController datePickerController = Get.put(DatePickerController());

  ViewReservationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green.shade400,
        title: Obx(() {
          return Text(DateFormat('yyyy-MM-dd')
              .format(datePickerController.selectedDate.value));
        }),
        actions: [
          IconButton(
              onPressed: () {
                datePickerController.pickDateReserve(context);
              },
              icon: Icon(Icons.edit_calendar))
        ],
      ),
      body: Obx(
        () {

        reservationController.viewReservations(DateFormat('yyyy-MM-dd')
            .format(datePickerController.selectedDate.value));


          if (reservationController.Done4.value == false) {
            return Center(
              child: CircularProgressIndicator(
                  color: Colors.green, backgroundColor: Colors.yellow),
            );
          } else {
            if (reservationController.reservations.isEmpty) {
              return Center(
                child: Text('There is no reservations today',
                    style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                        color: Colors.yellow.shade700)),
              );
            } else {
              {





                    return ListView.builder(
                        scrollDirection: Axis.vertical,
                        itemCount: reservationController.reservations.length,
                        itemBuilder: (BuildContext context, int i) {
                          return Container(
                              margin: EdgeInsets.all(20),
                              padding: EdgeInsets.fromLTRB(0, 20, 0, 0),
                              width: 80,
                              height: 290,
                              decoration: BoxDecoration(
                                  color: Colors.green.shade400,
                                  shape: BoxShape.rectangle,
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: List.filled(
                                      1,
                                      BoxShadow(
                                          color: Colors.grey,
                                          blurRadius: 10,
                                          offset: Offset(4, 4)))),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      Column(
                                        children: [
                                          Text('Date',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 17)),
                                          SizedBox(
                                            height: 7,
                                          ),
                                          Text(
                                              '${reservationController.reservations[i]['Date']}',
                                              style: TextStyle(
                                                  color: Colors.yellow.shade600,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 14)),
                                        ],
                                      ),
                                      Column(
                                        children: [
                                          Text('Start time',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 17)),
                                          SizedBox(
                                            height: 7,
                                          ),
                                          Text(
                                              '${reservationController.reservations[i]['Start']}',
                                              style: TextStyle(
                                                  color: Colors.yellow.shade600,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 17)),
                                        ],
                                      ),
                                      Column(
                                        children: [
                                          Text('End time',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 17)),
                                          SizedBox(
                                            height: 7,
                                          ),
                                          Text(
                                              '${reservationController.reservations[i]['End']}',
                                              style: TextStyle(
                                                  color: Colors.yellow.shade600,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 15)),
                                        ],
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Container(
                                    width: 300,
                                    height: 4,
                                    color: Colors.white,
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      Column(
                                        children: [
                                          Text('Name',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 17)),
                                          SizedBox(
                                            height: 7,
                                          ),
                                          Text(
                                              '${reservationController.reservations[i]['ReservationName']}',
                                              style: TextStyle(
                                                  color: Colors.yellow.shade600,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 20)),
                                        ],
                                      ),
                                      Column(
                                        children: [
                                          Text('Number',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 17)),
                                          SizedBox(
                                            height: 7,
                                          ),
                                          Text(
                                              '${reservationController.reservations[i]['Customers']}',
                                              style: TextStyle(
                                                  color: Colors.yellow.shade600,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 20)),
                                        ],
                                      ),
                                      Column(
                                        children: [
                                          Text('Birthday',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 17)),
                                          SizedBox(
                                            height: 7,
                                          ),
                                          Text(
                                              '${reservationController.reservations[i]['PossibleBirthday']}',
                                              style: TextStyle(
                                                  color: Colors.yellow.shade600,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 14)),
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 7,
                                  ),
                                  Container(
                                    width: 300,
                                    height: 4,
                                    color: Colors.white,
                                  ),
                                  SizedBox(
                                    height: 7,
                                  ),
                                  Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      Text('Tables',
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w700,
                                              fontSize: 17)),
                                      SizedBox(
                                        height: 7,
                                      ),
                                      Text('${reservationController.InfoTables.value[i]}',
                                          style: TextStyle(
                                              color: Colors.yellow.shade600,
                                              fontWeight: FontWeight.w700,
                                              fontSize: 17))
                                    ],
                                  ),
                                  SizedBox(
                                    height: 7,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [

                                      Container(
                                        margin: EdgeInsets.all(5),
                                        child: ElevatedButton(
                                            child: Icon(Icons.delete),
                                            style: ButtonStyle(
                                              shape: MaterialStatePropertyAll(
                                                CircleBorder(),
                                              ),
                                              backgroundColor:
                                                  MaterialStatePropertyAll(
                                                      Colors.redAccent),
                                            ),
                                            onPressed: () {
                                              print(reservationController
                                                  .reservations[i]['id']);
                                              reservationController
                                                  .deleteReservation(
                                                      reservationController
                                                              .reservations[i]
                                                          ['id']);


                                            }),
                                      ),
                                      Container(
                                        margin: EdgeInsets.all(5),
                                        child: ElevatedButton(
                                            child: Icon(Icons.arrow_forward_rounded),
                                            style: ButtonStyle(
                                              shape: MaterialStatePropertyAll(
                                                CircleBorder(),
                                              ),
                                              backgroundColor:
                                              MaterialStatePropertyAll(
                                                  Colors.yellow.shade700),
                                            ),
                                            onPressed: () {
                                              print(reservationController.reservations[i]['id']);
                                              serveController.toServe(reservationController.reservations[i]['id']);
                                              reservationController.Done4.value=false;


                                            }),
                                      ),


                                    ],
                                  ),
                                ],
                              ));
                        });




              }
            }
          }
        },
      ),
    );
  }
}
