import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:restaurant/controllers/Reservation/ReservationController.dart';

import 'package:restaurant/view/Widgets/InputTextFormField.dart';

class ReserveScreen extends StatelessWidget {
  final formKey = GlobalKey<FormState>();
  ReservationController reservationController =
  Get.put(ReservationController());


  ReserveScreen({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          backgroundColor: Colors.green.shade400,

        ),
        body: Obx(() {
          if (reservationController.Done1.value == false)
            return Container(
                height: 190,
                child: Center(
                  child: CircularProgressIndicator(
                      color: Colors.green, backgroundColor: Colors.yellow),
                ));
          else {
            return Form(
              key: formKey,
                child: Column(
                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                   Column(children: [

                     Row(
                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                       children: [
                         Container(

                             width: (MediaQuery.of(context).size.width/2)-20,
                             child: InputTextFormField(reservationController.reservationNameController, 'Reservation Name', 'NameValidator')),
                         Container(

                             width: (MediaQuery.of(context).size.width/2)-20,
                             child: InputTextFormField(reservationController.customersNumberController, 'Number', 'NumberValidator')),

                       ],
                     ),
                     SizedBox(height: 20),
                     Container(

                       width: (MediaQuery.of(context).size.width)-20,
                       child: Stack(
                         children: [
                           InputTextFormField(reservationController.customerPhoneNumberController, 'PhoneNumber', 'PhoneNumberValidator'),
                           (RegExp(r'^(?:[+0]9)?[0-9]{10}$').hasMatch(reservationController.customerPhoneNumberController.text))
                               ? Positioned(
                             right: -20,
                             bottom: -11,
                             child: Obx(
                                 (){
                                   reservationController.firstname.value;

                                   return ElevatedButton(

                                     onPressed: (){
                                       reservationController.showCustomer();




                                     },
                                     child: Icon(Icons.info),
                                     style: ButtonStyle(
                                         backgroundColor: MaterialStatePropertyAll(Colors.green.shade400),
                                         iconColor: MaterialStatePropertyAll(Colors.white),
                                         shape: MaterialStatePropertyAll(CircleBorder())
                                     ),
                                   );
                                 }
                             )
                           ):SizedBox()
                         ],
                       ),
                     ),

                   ],),

                    Column(
                      children: [
                        Text(
                          'Available Tables',
                          style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w700,
                              color: Colors.green.shade400),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                          color: Colors.yellow.shade600,
                          height: 4,
                          width: 150,
                        ),
                        Container(
                          height: 120,

                          child:
          reservationController.AvlTables.value.isNotEmpty
          ?ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: reservationController.AvlTables.value.length,
                              itemBuilder: (BuildContext context, int i) {
                                return Container(
                                    margin: EdgeInsets.all(10),
                                    width: 70,
                                    height: 110,
                                    decoration: BoxDecoration(
                                        color: Colors.green.shade400,
                                        shape: BoxShape.rectangle,
                                        borderRadius: BorderRadius.circular(20),
                                        boxShadow: List.filled(
                                            1,
                                            BoxShadow(
                                                color: Colors.grey,
                                                blurRadius: 5,
                                                offset: Offset(1, 1)))),
                                    child: Column(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Text('${reservationController.AvlTables.value[i]}',
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w700,
                                                fontSize: 16)),
                                        ElevatedButton(
                                          onPressed: () {

                                            reservationController.ResTables.value.add(reservationController.AvlTables.value[i]);
                                            reservationController.AvlTables.value.removeAt(i);
                                            var x =reservationController.AvlTables.value;
                                            reservationController.AvlTables.value=[];
                                            reservationController.AvlTables.value=x;

                                            print(reservationController.AvlTables.value);
                                            print(reservationController.ResTables.value);
                                          },
                                          child:
                                          Icon(Icons.add, color: Colors.green),
                                          style: ButtonStyle(
                                              shape: MaterialStatePropertyAll(
                                                  CircleBorder()),
                                              backgroundColor:
                                              MaterialStatePropertyAll(
                                                  Colors.yellow.shade600)),
                                        )
                                      ],
                                    ));
                              })
              :Center(
            child: Text('Nothing is Available',
                style: TextStyle(fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3,

                    color: Colors.yellow.shade700)),
          ),
                        ),
                      ],
                    ),



                   Column(
                     children: [
                       Text(
                         'Chosen Tables',
                         style: TextStyle(
                             fontSize: 22,
                             fontWeight: FontWeight.w700,
                             color: Colors.green.shade400),
                       ),
                       Container(
                         margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                         color: Colors.yellow.shade600,
                         height: 4,
                         width: 150,
                       ),
                       Text(
                         '${reservationController.ResTables.value.length} of ${reservationController.RevTables.value}',
                         style: TextStyle(
                             fontSize: 18,
                             fontWeight: FontWeight.w700,
                             color: Colors.yellow.shade600),
                       ),
                       Container(
                         height: 120,
                         child: reservationController.ResTables.value.isNotEmpty
                             ?ListView.builder(
                             scrollDirection: Axis.horizontal,
                             itemCount: reservationController.ResTables.value.length,
                             itemBuilder: (BuildContext context, int i) {
                               return Container(
                                   margin: EdgeInsets.all(10),
                                   width: 70,
                                   height: 110,
                                   decoration: BoxDecoration(
                                       color: Colors.green.shade400,
                                       shape: BoxShape.rectangle,
                                       borderRadius: BorderRadius.circular(20),
                                       boxShadow: List.filled(
                                           1,
                                           BoxShadow(
                                               color: Colors.grey,
                                               blurRadius: 5,
                                               offset: Offset(1, 1)))),
                                   child: Column(
                                     mainAxisAlignment:
                                     MainAxisAlignment.spaceEvenly,
                                     children: [
                                       Text('${reservationController.ResTables.value[i]}',
                                           style: TextStyle(
                                               color: Colors.white,
                                               fontWeight: FontWeight.w700,
                                               fontSize: 16)),
                                       ElevatedButton(
                                         onPressed: () {
                                           reservationController.AvlTables.value.add(reservationController.ResTables.value[i]);
                                           reservationController.ResTables.value.removeAt(i);
                                           reservationController.ResTables.value=reservationController.ResTables.value;
                                           var x =reservationController.ResTables.value;
                                           reservationController.ResTables.value=[];
                                           reservationController.ResTables.value=x;
                                           print(reservationController.AvlTables.value.toString());
                                           print(reservationController.ResTables.value);
                                         },
                                         child: Icon(Icons.remove,
                                             color: Colors.green),
                                         style: ButtonStyle(
                                             shape: MaterialStatePropertyAll(
                                                 CircleBorder()),
                                             backgroundColor:
                                             MaterialStatePropertyAll(
                                                 Colors.yellow.shade600)),
                                       )
                                     ],
                                   ));
                             })
                             :Center(
                           child: Text('Nothing is chosen',
                               style: TextStyle(fontSize: 22,
                                   fontWeight: FontWeight.w900,
                                   letterSpacing: 3,

                                   color: Colors.yellow.shade700)),
                         ),
                       ),
                     ],
                   ),


                    ElevatedButton(
                      style: ButtonStyle(
                          backgroundColor: MaterialStatePropertyAll(
                            Colors.yellow.shade600,
                          ),
                          shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                          padding: MaterialStatePropertyAll(EdgeInsets.all(0)),
                          elevation: MaterialStatePropertyAll(10)
                      ),
                      child: Container(

                        width: 100,
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'Submit',
                              style: TextStyle(
                                  fontSize: 20, fontWeight: FontWeight.w700),
                            ),

                          ],
                        ),
                      ),
                      onPressed: () {
    if (formKey.currentState!.validate()) {
      if(reservationController.RevTables.value=='${reservationController.ResTables.length}')
      reservationController.reserve();
      else
        Get.snackbar(
          'Error',
          'The number of tables should be ${reservationController.RevTables.value}',
          snackPosition: SnackPosition.BOTTOM,
          margin: EdgeInsets.only(bottom: 10),
          barBlur: 10000,
          backgroundColor: Colors.green,


        );

    }
                      },
                    )
                  ],
                ));
          }
        })



    );
  }
}
