import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:restaurant/controllers/Reservation/ReservationController.dart';

import 'package:restaurant/controllers/DatePickerController.dart';
import 'package:restaurant/controllers/TimePickerController.dart';
import 'package:restaurant/view/Widgets/InputTextFormField.dart';

class CheckReservationsScreen extends StatelessWidget {
  final formKey = GlobalKey<FormState>();

  ReservationController reservationController =
      Get.put(ReservationController());
  DatePickerController datePickerController = Get.put(DatePickerController());
  TimePickerController timePickerController = Get.put(TimePickerController());

  CheckReservationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var loading = false.obs;

    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          backgroundColor: Colors.green.shade400,
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Column(
              children: [
                SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        Text(
                          'Date',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              color: Colors.green.shade400),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Obx(() {
                          return ElevatedButton(
                            style: ButtonStyle(
                              backgroundColor: MaterialStatePropertyAll(
                                Colors.green.shade400,
                              ),
                              shape: MaterialStatePropertyAll(
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10))),
                              padding:
                                  MaterialStatePropertyAll(EdgeInsets.all(10)),
                            ),
                            child: reservationController.RevDate == ''
                                ? Text(
                                    'not selected',
                                    style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700),
                                  )
                                : Text(
                                    DateFormat(' yyyy-MM-dd ').format(
                                        datePickerController
                                            .selectedDate.value),
                                    style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700),
                                  ),
                            onPressed: () {
                              datePickerController
                                  .pickDateCheckReserve(context);
                            },
                          );
                        }),
                      ],
                    ),
                    Column(
                      children: [
                        Text(
                          'Tables',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              color: Colors.green.shade400),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Obx(() {
                          return ElevatedButton(
                            style: ButtonStyle(
                              backgroundColor: MaterialStatePropertyAll(
                                Colors.green.shade400,
                              ),
                              shape: MaterialStatePropertyAll(
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10))),
                              padding:
                                  MaterialStatePropertyAll(EdgeInsets.all(10)),
                            ),
                            child: Text(
                              reservationController.RevTables.value == ''
                                  ? 'not selected'
                                  : '         ${reservationController.RevTables.value}         ',
                              style: TextStyle(
                                  fontSize: 17, fontWeight: FontWeight.w700),
                            ),
                            onPressed: () {
                              Get.dialog(
                                AlertDialog(
                                  shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(30))),
                                  content: Container(
                                    width: 150,
                                    height: 102,
                                    child: Column(
                                      children: [
                                        Text('Tables',
                                            style: TextStyle(
                                                color: Colors.green,
                                                fontWeight: FontWeight.w700,
                                                fontSize: 20)),
                                        SizedBox(
                                          height: 20,
                                        ),
                                        InputTextFormField(
                                            reservationController
                                                .RevTablesController,
                                            'Number',
                                            'NumberValidator')
                                      ],
                                    ),
                                  ),
                                  actions: [
                                    TextButton(
                                        onPressed: () {
                                          reservationController
                                                  .RevTables.value =
                                              reservationController
                                                  .RevTablesController.text;

                                          Get.back();
                                        },
                                        child: Text(
                                          'Enter',
                                          style: TextStyle(
                                              color: Colors.yellow.shade600,
                                              fontSize: 18,
                                              fontWeight: FontWeight.w700),
                                        ))
                                  ],
                                ),
                              );
                            },
                          );
                        }),
                      ],
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        Text(
                          'Start Time',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              color: Colors.green.shade400),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Obx(() {
                          return ElevatedButton(
                            style: ButtonStyle(
                              backgroundColor: MaterialStatePropertyAll(
                                Colors.green.shade400,
                              ),
                              shape: MaterialStatePropertyAll(
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10))),
                              padding:
                                  MaterialStatePropertyAll(EdgeInsets.all(10)),
                            ),
                            child: reservationController.RevStart == ''
                                ? Text(
                                    'not selected',
                                    style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700),
                                  )
                                : Text(
                                    reservationController.RevStart.value,
                                    style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700),
                                  ),
                            onPressed: () {
                              timePickerController.pickTimeStart(context);
                            },
                          );
                        })
                      ],
                    ),
                    Column(
                      children: [
                        Text(
                          'End Time',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              color: Colors.green.shade400),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Obx(() {
                          return ElevatedButton(
                            style: ButtonStyle(
                              backgroundColor: MaterialStatePropertyAll(
                                Colors.green.shade400,
                              ),
                              shape: MaterialStatePropertyAll(
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10))),
                              padding:
                                  MaterialStatePropertyAll(EdgeInsets.all(10)),
                            ),
                            child: reservationController.RevEnd == ''
                                ? Text(
                                    'not selected',
                                    style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700),
                                  )
                                : Text(
                                    reservationController.RevEnd.value,
                                    style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700),
                                  ),
                            onPressed: () {
                              timePickerController.pickTimeEnd(context);
                            },
                          );
                        })
                      ],
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStatePropertyAll(
                      Colors.yellow.shade600,
                    ),
                    shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20))),
                    padding: MaterialStatePropertyAll(EdgeInsets.all(0)),
                  ),
                  child: Container(
                    width: 120,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Check',
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w700),
                        ),
                        Icon(
                          Icons.arrow_drop_down,
                          size: 35,
                        )
                      ],
                    ),
                  ),
                  onPressed: () {
                    reservationController.Done1.value = false;
                    reservationController.checkReservation();
                    if (reservationController.RevEnd == '' ||
                        reservationController.RevTables == '' ||
                        reservationController.RevStart == '' ||
                        reservationController.RevDate == '')
                      loading.value = false;
                    else
                      loading.value = true;
                  },
                )
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Obx(() {
              if (loading.value == true) {
                if ((reservationController.Done1.value == false))
                  return Column(
                    children: [
                      Text(
                        'Available Tables',
                        style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w700,
                            color: Colors.green.shade400),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                        color: Colors.yellow.shade600,
                        height: 4,
                        width: 150,
                      ),

                      Container(
                          height: 190,
                          child: Center(
                            child: CircularProgressIndicator(
                                color: Colors.green.shade400,
                                backgroundColor: Colors.yellow.shade600),
                          ))

                    ],
                  );
                else {
                  if (reservationController.AvlTables.value.isNotEmpty&&reservationController.checkReservationMessage.value!='reservation not available'&&reservationController.checkReservationMessage.value!='too many tables') {
                    return Column(
                      children: [
                        Text(
                          'Available Tables',
                          style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w700,
                              color: Colors.green.shade400),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                          color: Colors.yellow.shade600,
                          height: 4,
                          width: 150,
                        ),
                        Container(
                          height: 190,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Text(
                                  '${reservationController.AvlTables.value.length}',
                                  style: TextStyle(
                                      color: Colors.yellow.shade600,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 25)),
                              ElevatedButton(
                                style: ButtonStyle(
                                  backgroundColor: MaterialStatePropertyAll(
                                    Colors.green.shade400,
                                  ),
                                  shape: MaterialStatePropertyAll(
                                      RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(20))),
                                  padding: MaterialStatePropertyAll(
                                      EdgeInsets.all(0)),
                                ),
                                child: Container(
                                  width: 130,
                                  child: const Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        'Reserve',
                                        style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.w700),
                                      ),
                                      Icon(
                                        Icons.arrow_right,
                                        size: 35,
                                      )
                                    ],
                                  ),
                                ),
                                onPressed: () {
                                  reservationController.ResDate.value=reservationController.RevDate.value;
                                  reservationController.ResStart.value=reservationController.RevStart.value;
                                  reservationController.ResEnd.value=reservationController.RevEnd.value;
                                  reservationController.AvlTables.value=reservationController.AvlTables.value;
                                  reservationController.ResTables.value=[];

                                  Get.toNamed('ReserveScreen');
                                },
                              )
                            ],
                          ),
                        ),
                      ],
                    );
                  } else {
                    if (reservationController.checkReservationMessage.value == 'reservation not available') {
                      return Column(
                        children: [
                          Text(
                            'Available Dates',
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w700,
                                color: Colors.green.shade400),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                            color: Colors.yellow.shade600,
                            height: 4,
                            width: 150,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Container(
                                height: 190,
                                child: Center(
                                  child: Column(
                                    children: [
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text('Before',
                                          style: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 2,
                                              color: Colors.yellow.shade700)),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                          reservationController
                                              .nearbyreservationBefore
                                              .value['RevDate'],
                                          style: TextStyle(
                                              fontSize: 17,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 2,
                                              color: Colors.yellow.shade700)),
                                      Text(
                                          'Start: ${reservationController.nearbyreservationBefore.value['RevStart']}',
                                          style: TextStyle(
                                              fontSize: 17,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 2,
                                              color: Colors.yellow.shade700)),
                                      Text(
                                          'End: ${reservationController.nearbyreservationBefore.value['RevEnd']}',
                                          style: TextStyle(
                                              fontSize: 17,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 2,
                                              color: Colors.yellow.shade700)),
                                      Text(
                                          'Tables: ${reservationController.TablesBefore.length.toString()}',
                                          style: TextStyle(
                                              fontSize: 17,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 2,
                                              color: Colors.yellow.shade700)),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      ElevatedButton(
                                        style: ButtonStyle(
                                          backgroundColor:
                                              MaterialStatePropertyAll(
                                            Colors.green.shade400,
                                          ),
                                          shape: MaterialStatePropertyAll(
                                              RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          20))),
                                          padding: MaterialStatePropertyAll(
                                              EdgeInsets.all(0)),
                                        ),
                                        child: Container(
                                          width: 130,
                                          child: const Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Text(
                                                'Reserve',
                                                style: TextStyle(
                                                    fontSize: 20,
                                                    fontWeight:
                                                        FontWeight.w700),
                                              ),
                                              Icon(
                                                Icons.arrow_right,
                                                size: 35,
                                              )
                                            ],
                                          ),
                                        ),
                                        onPressed: () {
                                          reservationController.ResDate.value=reservationController.nearbyreservationBefore.value['RevDate'];
                                          reservationController.ResStart.value=reservationController.nearbyreservationBefore.value['RevStart'];
                                          reservationController.ResEnd.value=reservationController.nearbyreservationBefore.value['RevEnd'];
                                          reservationController.AvlTables.value=reservationController.TablesBefore.value;
                                          reservationController.ResTables.value=[];
                                          Get.toNamed('ReserveScreen');
                                        },
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                height: 190,
                                child: Center(
                                  child: Column(
                                    children: [
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text('After',
                                          style: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 2,
                                              color: Colors.yellow.shade700)),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                          reservationController
                                              .nearbyreservationAfter
                                              .value['RevDate'],
                                          style: TextStyle(
                                              fontSize: 17,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 2,
                                              color: Colors.yellow.shade700)),
                                      Text(
                                          'Start: ${reservationController.nearbyreservationAfter.value['RevStart']}',
                                          style: TextStyle(
                                              fontSize: 17,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 2,
                                              color: Colors.yellow.shade700)),
                                      Text(
                                          'End: ${reservationController.nearbyreservationAfter.value['RevEnd']}',
                                          style: TextStyle(
                                              fontSize: 17,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 2,
                                              color: Colors.yellow.shade700)),
                                      Text(
                                          'Tables: ${reservationController.TablesAfter.length.toString()}',
                                          style: TextStyle(
                                              fontSize: 17,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 2,
                                              color: Colors.yellow.shade700)),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      ElevatedButton(
                                        style: ButtonStyle(
                                          backgroundColor:
                                              MaterialStatePropertyAll(
                                            Colors.green.shade400,
                                          ),
                                          shape: MaterialStatePropertyAll(
                                              RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          20))),
                                          padding: MaterialStatePropertyAll(
                                              EdgeInsets.all(0)),
                                        ),
                                        child: Container(
                                          width: 130,
                                          child: const Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Text(
                                                'Reserve',
                                                style: TextStyle(
                                                    fontSize: 20,
                                                    fontWeight:
                                                        FontWeight.w700),
                                              ),
                                              Icon(
                                                Icons.arrow_right,
                                                size: 35,
                                              )
                                            ],
                                          ),
                                        ),
                                        onPressed: () {

                                          reservationController.ResDate.value=reservationController.nearbyreservationAfter.value['RevDate'];
                                          reservationController.ResStart.value=reservationController.nearbyreservationAfter.value['RevStart'];
                                          reservationController.ResEnd.value=reservationController.nearbyreservationAfter.value['RevEnd'];
                                          reservationController.AvlTables.value=reservationController.TablesAfter.value;
                                          reservationController.ResTables.value=[];
                                          Get.toNamed('ReserveScreen');
                                        },
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          )
                        ],
                      );
                    }
                    else if (reservationController.checkReservationMessage.value == 'too many tables') {
                      return Column(
                        children: [
                          Text(
                            'Available Tables',
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w700,
                                color: Colors.green.shade400),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                            color: Colors.yellow.shade600,
                            height: 4,
                            width: 150,
                          ),
                          Container(
                            height: 190,
                            child: Center(
                              child: Text('Too Many Tables',
                                  style: TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 2,
                                      color: Colors.yellow.shade700)),
                            ),
                          )
                        ],
                      );
                    } else {
                      return Column(
                        children: [
                          Text(
                            'Available Tables',
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w700,
                                color: Colors.green.shade400),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                            color: Colors.yellow.shade600,
                            height: 4,
                            width: 150,
                          ),
                          Container(
                            height: 190,
                            child: Center(
                              child: Text('No Available Tables',
                                  style: TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 2,
                                      color: Colors.yellow.shade700)),
                            ),
                          )
                        ],
                      );
                    }
                  }
                }
              } else {
                return Column(
                  children: [
                    Text(
                      'Available Tables',
                      style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w700,
                          color: Colors.green.shade400),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                      color: Colors.yellow.shade600,
                      height: 4,
                      width: 150,
                    ),
                    Container(
                      height: 190,
                      child: Center(
                        child: Text('Not Checked',
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2,
                                color: Colors.yellow.shade700)),
                      ),
                    )
                  ],
                );
              }
            }),
          ],
        ));
  }
}
