
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant/controllers/Tables/BossTablesController.dart';

import '../Widgets/InputTextFormField.dart';



bool x=false;
bool y=false;



class BossTablesScreen extends StatelessWidget {

  final formKey = GlobalKey<FormState>();
 final BossTablesController bossTablesController = Get.put(BossTablesController());


  BossTablesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green.shade400,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [

          Column(children: [
            Text('Available Tables',
              style: TextStyle(fontSize: 25,
                  fontWeight: FontWeight.w700,
                  color: Colors.green.shade400
              ),
            ),
            Container(
              color: Colors.yellow.shade600,
              height: 4,
              width: 150,
            ),
            Obx(
                  (){







                if(bossTablesController.Done1.value == false){
                  bossTablesController.showAvilableTables();

                  return Container(
                      height: 190,
                      child: Center(child: CircularProgressIndicator(color: Colors.green,backgroundColor: Colors.yellow),));
                }
                else{
                  if(bossTablesController.availableTables.isEmpty){
                    return Container(
                        margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
                        height: 150,
                        padding: EdgeInsets.all(10),
                        child: Center(
                          child: Text('There is no available tables',
                              style: TextStyle(fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 2,

                                  color: Colors.yellow.shade700)),
                        )

                    );
                  }
                  else {
                    return  Container(
                      margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
                      height: 150,
                      padding: EdgeInsets.all(10),

                      child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: bossTablesController.availableTables.length,
                          itemBuilder: (BuildContext context,int i) {
                            return Container(
                                margin: EdgeInsets.all(10),
                                width: 130,
                                height: 130,

                                decoration: BoxDecoration(
                                    color: Colors.green.shade400,
                                    shape: BoxShape.rectangle,
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: List.filled(1, BoxShadow(color: Colors.grey,blurRadius: 5,offset: Offset(1, 1)))),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [

                                    Text('${bossTablesController.availableTables[i]['id']}',
                                        style: TextStyle(color: Colors.white,
                                            fontWeight: FontWeight.w700,
                                            fontSize: 20)),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                      ElevatedButton(
                                        onPressed: (){
                                          bossTablesController.infoTable(bossTablesController.availableTables[i]['id']);



                                        },
                                        child: Icon(Icons.info_outline,color: Colors.green),
                                        style: ButtonStyle(

                                            shape: MaterialStatePropertyAll(CircleBorder()),
                                            backgroundColor: MaterialStatePropertyAll(Colors.yellow.shade600),

                                        ),
                                      ),
                                      ElevatedButton(
                                        onPressed: (){
                                          bossTablesController.blockUnblockTables(bossTablesController.availableTables[i]['id']);

                                        },
                                        child: Icon(Icons.lock_outlined,color: Colors.green),
                                        style: ButtonStyle(shape: MaterialStatePropertyAll(CircleBorder()),
                                            backgroundColor: MaterialStatePropertyAll(Colors.yellow.shade600)),
                                      ),
                                    ],),
                                  ],
                                ));
                          }
                      ),
                    );
                  }

                }

              }
              ,),
          ],),


          Column(
            children: [
              Text('Blocked Tables',
                style: TextStyle(fontSize: 25,
                    fontWeight: FontWeight.w700,
                    color: Colors.green.shade400
                ),
              ),
              Container(
                color: Colors.yellow.shade600,
                height: 4,
                width: 150,
              ),
              Obx(
                    (){




                  if(bossTablesController.Done2.value == false){
                    bossTablesController.showBlockedTables();
                    return Container(
                        height: 190,
                        child: Center(child: CircularProgressIndicator(color: Colors.green,backgroundColor: Colors.yellow),));
                  }
                  else{
                    if(bossTablesController.blockedTables.isEmpty){
                      return Container(
                          margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
                          height: 150,
                          padding: EdgeInsets.all(10),
                          child: Center(
                            child: Text('There is no blocked tables',
                                style: TextStyle(fontSize: 22,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 2,

                                    color: Colors.yellow.shade700)),
                          )

                      );
                    }
                    else
                      return Container(
                        margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
                        height: 150,
                        padding: EdgeInsets.all(10),

                        child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: bossTablesController.blockedTables.length,
                            itemBuilder: (BuildContext context,int i) {
                              return Container(
                                  margin: EdgeInsets.all(10),
                                  width: 80,
                                  height: 130,

                                  decoration: BoxDecoration(
                                      color: Colors.yellow.shade600,
                                      shape: BoxShape.rectangle,
                                      borderRadius: BorderRadius.circular(20),
                                      boxShadow: List.filled(1, BoxShadow(color: Colors.grey,blurRadius: 5,offset: Offset(1, 1)))),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      Text('${bossTablesController.blockedTables[i]['id']}',
                                          style: TextStyle(color: Colors.white,
                                              fontWeight: FontWeight.w700,
                                              fontSize: 20)),
                                      ElevatedButton(onPressed: (){
                                        bossTablesController.blockUnblockTables(bossTablesController.blockedTables[i]['id']);

                                      },
                                        child: Icon(Icons.lock_open),
                                        style: ButtonStyle(shape: MaterialStatePropertyAll(CircleBorder()),
                                            backgroundColor: MaterialStatePropertyAll(Colors.green.shade400)),
                                      )
                                    ],
                                  ));
                            }
                        ),
                      );

                  }

                }
                ,),
              ElevatedButton(

                  style: ButtonStyle(
                    elevation: MaterialStatePropertyAll(5),
                    backgroundColor: MaterialStatePropertyAll(Colors.green.shade400),
                    shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20)))),

                  ),

                  onPressed: (){
                    Get.dialog(AlertDialog(
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                              Radius.circular(30))),
                      content: Container(
                        width: 150,
                        height: 102,
                        child: Column(
                          children: [
                            Text('Enter Tables Number',
                                style: TextStyle(
                                    color: Colors.yellow.shade700,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 20)),
                            SizedBox(
                              height: 20,
                            ),
                            InputTextFormField(bossTablesController.editTablesController, 'Number', 'NumberValidator')
                          ],
                        ),
                      ),
                      actions: [
                        TextButton(
                            onPressed: () {

                              bossTablesController.editTablesNumber();
                              Get.back();


                            },
                            child: Text(
                              'Submit',
                              style: TextStyle(
                                  color: Colors.yellow.shade700,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700),
                            ))
                      ],
                    ),);
                  }
                  , child: Container(
                width: 120,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Edit Tables',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700
                        )),
                    Icon(Icons.edit)
                  ],
                ),
              ))
            ],
          ),



        ],
      ),
    );
  }
}