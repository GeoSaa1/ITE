import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class Cards extends StatelessWidget {
  final String id;
  final String title;
  final String imageURL;
  final String pageURL;

  Cards(this.id,this.title,this.imageURL,this.pageURL);

  @override
  Widget build(BuildContext context) {
    return GridTile(
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          width: MediaQuery.of(context).size.width,
          height: 180,

          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                offset: Offset(0.0, 10.0,),
                blurRadius: 10.0,
                spreadRadius: -6.0,),
            ],
            image: DecorationImage(
              colorFilter: ColorFilter.mode(
                Colors.green.shade400,
                BlendMode.multiply,
              ),
              image: AssetImage(imageURL,),
              // alignment: Alignment.bottomCenter,
              fit: BoxFit.cover,
            alignment: Alignment(1, 1)
            ),
          ),
          child: Stack(
            children: [
              Align(
                child: Padding(

                  padding: EdgeInsets.symmetric(horizontal: 5.0,),
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)),
                        primary: Colors.yellow.shade600,),
                      onPressed: (){
                        Get.toNamed(pageURL);
                      },
                      child: Text(title,
                        style:
                        TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      )
                ),
                ),
                alignment: Alignment(0, 1.07),
              ),
            ],
          ),
        ),
    );
  }
}
