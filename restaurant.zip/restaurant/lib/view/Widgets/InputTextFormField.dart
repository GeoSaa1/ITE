import 'package:flutter/material.dart';

class InputTextFormField extends StatelessWidget {
  final TextEditingController textEditingController;
  final String hinttext;
  final String validator;

  InputTextFormField( this.textEditingController, this.hinttext, this.validator);

  @override
  Widget build(BuildContext context) {
    if (validator == "NameValidator")
      return TextFormField(
        controller: textEditingController,
        decoration: InputDecoration(
          labelText: hinttext,
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),

          ),
          errorBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colors.red,
              ),
              borderRadius: BorderRadius.circular(18)),
          focusedErrorBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colors.red,
              ),
              borderRadius: BorderRadius.circular(18)),

          floatingLabelBehavior: FloatingLabelBehavior.never,
        ),
        validator: (value) {
          if (value!.isEmpty || !RegExp("^[A-Za-z]").hasMatch(value))
            return "Enter a Valid $hinttext";
          else
            return null;
        },
      );
    if (validator == "EmailValidator")
      return TextFormField(
        controller: textEditingController,
        decoration: InputDecoration(
          labelText: hinttext,
          prefixIcon: Icon(Icons.email, color: Colors.grey),
        ),
        validator: (value) {
          if (value!.isEmpty ||
              !RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                  .hasMatch(value))
            return "Enter correct $hinttext";
          else
            return null;
        },
      );
    if (validator == "PasswordValidator")
      return TextFormField(
        controller: textEditingController,
        obscureText: true,
        decoration: InputDecoration(
          labelText: hinttext,
          prefixIcon: Icon(Icons.lock, color: Colors.grey),
        ),
        validator: (value){
          if(value!.isEmpty||!RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#$&*~]).{8,}$').hasMatch(value))
            return "Enter a Valid $hinttext";
          else
            return null;
        },

      );
    if (validator == "PhoneNumberValidator")
      return TextFormField(
        controller: textEditingController,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: hinttext,
        ),
        validator: (value){
          if(value!.isEmpty||!RegExp(r'^(?:[+0]9)?[0-9]{10}$').hasMatch(value))
            return "Enter a Valid $hinttext";
          else
            return null;
        },

      );
    if (validator == "NumberValidator")
      return TextFormField(
        controller: textEditingController,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: hinttext,
        ),
        validator: (value){
          if(value!.isEmpty)
            return "Enter a Valid $hinttext";
          else
            return null;
        },

      );
    else
      return TextFormField(
        controller: textEditingController,
        decoration: InputDecoration(
          labelText: hinttext,


        ),
        validator: (value){
          if(value!.isEmpty)
            return "Enter ${hinttext}";
          else
            return null;
        },

      );
  }
}
